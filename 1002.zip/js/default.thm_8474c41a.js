window.skins={};
                function __extends(d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = {};
                generateEUI.paths = {};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml","Component.ProgressBar":"resource/skins/component/ProgressBar.exml","component.Toast":"resource/skins/component/Toast.exml","StateTipEffect":"resource/effect/ksxz.exml","Effect_TongSha":"resource/effect/tongsha.exml","Effect_TongPei":"resource/effect/tongpei.exml","Effect_betpos_1":"resource/effect/shunhilight.exml","Effect_betpos_2":"resource/effect/tianhilight.exml","Effect_betpos_3":"resource/effect/dihilight.exml","Effect_flipMJPos1":"resource/effect/pos1.exml","Effect_flipMJPos2":"resource/effect/pos2.exml","Effect_flipMJPos3":"resource/effect/pos3.exml","Effect_MJPos_1":"resource/effect/majiang_pos_1.exml","Effect_MJPos_2":"resource/effect/majiang_pos_2.exml","Effect_MJPos_3":"resource/effect/majiang_pos_3.exml","Effect_MJPos_4":"resource/effect/majiang_pos_4.exml","Effect_tiangang":"resource/effect/tiangang.exml"};generateEUI.paths['resource/effect/dihilight.exml'] = window.dihilight = (function (_super) {
	__extends(dihilight, _super);
	function dihilight() {
		_super.call(this);
		this.skinParts = ["di","img_bian","img_kuai","group"];
		
		this.height = 250;
		this.width = 350;
		this.di_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["img_kuai"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, ["img_bian"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
	}
	var _proto = dihilight.prototype;

	_proto.di_i = function () {
		var t = new egret.tween.TweenGroup();
		this.di = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i(),this._To3_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To4_i(),this._To5_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 1750;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 700;
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 250;
		t.width = 350;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.img_bian_i(),this.img_kuai_i()];
		return t;
	};
	_proto.img_bian_i = function () {
		var t = new eui.Image();
		this.img_bian = t;
		t.source = "effect_di_00_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.img_kuai_i = function () {
		var t = new eui.Image();
		this.img_kuai = t;
		t.blendMode = "add";
		t.source = "effect_di00_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	return dihilight;
})(eui.Skin);generateEUI.paths['resource/effect/ksxz.exml'] = window.NewFile = (function (_super) {
	__extends(NewFile, _super);
	function NewFile() {
		_super.call(this);
		this.skinParts = ["ksxz","tzxz","zxmp","ksyx","shop","zxfp"];
		
		this.height = 200;
		this.width = 800;
		this.ksxz_i();
		this.tzxz_i();
		this.zxmp_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["ksyx"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object3,"scaleY");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"scaleY");
		eui.Binding.$bindProperties(this, ["shop"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object7,"scaleY");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"scaleY");
		eui.Binding.$bindProperties(this, ["zxfp"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object11,"scaleY");
		eui.Binding.$bindProperties(this, [0],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object12,"scaleY");
	}
	var _proto = NewFile.prototype;

	_proto.ksxz_i = function () {
		var t = new egret.tween.TweenGroup();
		this.ksxz = t;
		t.items = [this._TweenItem1_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._Wait1_i(),this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto.tzxz_i = function () {
		var t = new egret.tween.TweenGroup();
		this.tzxz = t;
		t.items = [this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set3_i(),this._To3_i(),this._Wait2_i(),this._Set4_i(),this._To4_i()];
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto.zxmp_i = function () {
		var t = new egret.tween.TweenGroup();
		this.zxmp = t;
		t.items = [this._TweenItem3_i()];
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set5_i(),this._To5_i(),this._Wait3_i(),this._Set6_i(),this._To6_i()];
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._To6_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.ksyx_i(),this.shop_i(),this.zxfp_i()];
		return t;
	};
	_proto.ksyx_i = function () {
		var t = new eui.Image();
		this.ksyx = t;
		t.anchorOffsetX = 405.05;
		t.anchorOffsetY = 79;
		t.horizontalCenter = 0;
		t.scaleX = 0.99;
		t.source = "kuang_png";
		t.verticalCenter = -30;
		t.visible = false;
		return t;
	};
	_proto.shop_i = function () {
		var t = new eui.Image();
		this.shop = t;
		t.anchorOffsetX = 407;
		t.anchorOffsetY = 97;
		t.horizontalCenter = 0;
		t.source = "tzxz_png";
		t.verticalCenter = -30;
		return t;
	};
	_proto.zxfp_i = function () {
		var t = new eui.Image();
		this.zxfp = t;
		t.anchorOffsetX = 404;
		t.anchorOffsetY = 95;
		t.horizontalCenter = 0;
		t.source = "zxmk_png";
		t.verticalCenter = -30;
		t.visible = false;
		return t;
	};
	return NewFile;
})(eui.Skin);generateEUI.paths['resource/effect/majiang_pos_1.exml'] = window.majiang_pos_1 = (function (_super) {
	__extends(majiang_pos_1, _super);
	function majiang_pos_1() {
		_super.call(this);
		this.skinParts = ["anim","image","image0","group"];
		
		this.height = 100;
		this.width = 200;
		this.anim_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
	}
	var _proto = majiang_pos_1.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 750;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 100;
		t.width = 200;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image_i(),this.image0_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.left = 37;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "majiang_pos_1_2_png";
		t.top = 16;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.blendMode = "add";
		t.left = 37;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "majiang_pos_1_1_png";
		t.top = 16;
		return t;
	};
	return majiang_pos_1;
})(eui.Skin);generateEUI.paths['resource/effect/majiang_pos_2.exml'] = window.majiang_pos_2 = (function (_super) {
	__extends(majiang_pos_2, _super);
	function majiang_pos_2() {
		_super.call(this);
		this.skinParts = ["anim","image0","image","group"];
		
		this.height = 100;
		this.width = 200;
		this.anim_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
	}
	var _proto = majiang_pos_2.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 750;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 100;
		t.width = 200;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image0_i(),this.image_i()];
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.left = 42;
		t.source = "majiang_pos_2_2_png";
		t.top = 16;
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.blendMode = "add";
		t.left = 42;
		t.source = "majiang_pos_2_1_png";
		t.top = 16;
		return t;
	};
	return majiang_pos_2;
})(eui.Skin);generateEUI.paths['resource/effect/majiang_pos_3.exml'] = window.majiang_pos_3 = (function (_super) {
	__extends(majiang_pos_3, _super);
	function majiang_pos_3() {
		_super.call(this);
		this.skinParts = ["anim","image0","image","group"];
		
		this.height = 100;
		this.width = 200;
		this.anim_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
	}
	var _proto = majiang_pos_3.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 750;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 100;
		t.width = 200;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image0_i(),this.image_i()];
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.left = 37;
		t.source = "majiang_pos_3_2_png";
		t.top = 16;
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.blendMode = "add";
		t.left = 37;
		t.source = "majiang_pos_3_1_png";
		t.top = 16;
		return t;
	};
	return majiang_pos_3;
})(eui.Skin);generateEUI.paths['resource/effect/majiang_pos_4.exml'] = window.majiang_pos_4 = (function (_super) {
	__extends(majiang_pos_4, _super);
	function majiang_pos_4() {
		_super.call(this);
		this.skinParts = ["anim","image","image0","group"];
		
		this.height = 100;
		this.width = 200;
		this.anim_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
	}
	var _proto = majiang_pos_4.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 750;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 100;
		t.width = 200;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image_i(),this.image0_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.source = "majiang_pos_4_1_png";
		t.x = 0;
		t.y = -1;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.blendMode = "add";
		t.source = "majiang_pos_4_2_png";
		t.x = 0;
		t.y = -1;
		return t;
	};
	return majiang_pos_4;
})(eui.Skin);generateEUI.paths['resource/effect/pos1.exml'] = window.破碎 = (function (_super) {
	__extends(破碎, _super);
	function 破碎() {
		_super.call(this);
		this.skinParts = ["anim","image","image0","image1","image2"];
		
		this.height = 84;
		this.width = 66;
		this.anim_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, ["image1"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, ["image2"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"alpha");
	}
	var _proto = 破碎.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._Wait1_i(),this._Set2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set3_i(),this._Wait2_i(),this._Set4_i(),this._Wait3_i(),this._Set5_i()];
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set6_i(),this._Wait4_i(),this._Set7_i(),this._Wait5_i(),this._Set8_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set9_i(),this._Wait6_i(),this._Set10_i(),this._Wait7_i(),this._Set11_i()];
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 300;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 84;
		t.width = 66;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image_i(),this.image0_i(),this.image1_i(),this.image2_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_101";
		t.top = 0;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_102";
		t.top = 0;
		return t;
	};
	_proto.image1_i = function () {
		var t = new eui.Image();
		this.image1 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_103";
		t.top = 0;
		return t;
	};
	_proto.image2_i = function () {
		var t = new eui.Image();
		this.image2 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_104";
		t.top = 0;
		return t;
	};
	return 破碎;
})(eui.Skin);generateEUI.paths['resource/effect/pos2.exml'] = window.破碎 = (function (_super) {
	__extends(破碎, _super);
	function 破碎() {
		_super.call(this);
		this.skinParts = ["anim","image","image0","image1","image2"];
		
		this.height = 80;
		this.width = 58;
		this.anim_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, ["image1"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, ["image2"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"alpha");
	}
	var _proto = 破碎.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._Wait1_i(),this._Set2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set3_i(),this._Wait2_i(),this._Set4_i(),this._Wait3_i(),this._Set5_i()];
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set6_i(),this._Wait4_i(),this._Set7_i(),this._Wait5_i(),this._Set8_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set9_i(),this._Wait6_i(),this._Set10_i(),this._Wait7_i(),this._Set11_i()];
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 300;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 80;
		t.width = 58;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image_i(),this.image0_i(),this.image1_i(),this.image2_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_201";
		t.top = 0;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_202";
		t.top = 0;
		return t;
	};
	_proto.image1_i = function () {
		var t = new eui.Image();
		this.image1 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_203";
		t.top = 0;
		return t;
	};
	_proto.image2_i = function () {
		var t = new eui.Image();
		this.image2 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_204";
		t.top = 0;
		return t;
	};
	return 破碎;
})(eui.Skin);generateEUI.paths['resource/effect/pos3.exml'] = window.破碎 = (function (_super) {
	__extends(破碎, _super);
	function 破碎() {
		_super.call(this);
		this.skinParts = ["anim","image","image0","image1","image2"];
		
		this.height = 83;
		this.width = 75;
		this.anim_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, ["image1"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, ["image2"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"alpha");
	}
	var _proto = 破碎.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._Wait1_i(),this._Set2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set3_i(),this._Wait2_i(),this._Set4_i(),this._Wait3_i(),this._Set5_i()];
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set6_i(),this._Wait4_i(),this._Set7_i(),this._Wait5_i(),this._Set8_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set9_i(),this._Wait6_i(),this._Set10_i(),this._Wait7_i(),this._Set11_i()];
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 300;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 83;
		t.width = 75;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.image_i(),this.image0_i(),this.image1_i(),this.image2_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_301";
		t.top = 0;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_302";
		t.top = 0;
		return t;
	};
	_proto.image1_i = function () {
		var t = new eui.Image();
		this.image1 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_303";
		t.top = 0;
		return t;
	};
	_proto.image2_i = function () {
		var t = new eui.Image();
		this.image2 = t;
		t.left = 0;
		t.source = "pos_json.UI_28_majiangxulie_304";
		t.top = 0;
		return t;
	};
	return 破碎;
})(eui.Skin);generateEUI.paths['resource/effect/shunhilight.exml'] = window.NewFile = (function (_super) {
	__extends(NewFile, _super);
	function NewFile() {
		_super.call(this);
		this.skinParts = ["shun","img_bian","img_kuai","group"];
		
		this.height = 250;
		this.width = 350;
		this.shun_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["img_kuai"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, ["img_bian"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
	}
	var _proto = NewFile.prototype;

	_proto.shun_i = function () {
		var t = new egret.tween.TweenGroup();
		this.shun = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i(),this._To3_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To4_i(),this._To5_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 1750;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 700;
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 250;
		t.width = 350;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.img_bian_i(),this.img_kuai_i()];
		return t;
	};
	_proto.img_bian_i = function () {
		var t = new eui.Image();
		this.img_bian = t;
		t.source = "effect_shun_0_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.img_kuai_i = function () {
		var t = new eui.Image();
		this.img_kuai = t;
		t.blendMode = "add";
		t.source = "effect_shun0_png";
		t.x = 0;
		t.y = 1;
		return t;
	};
	return NewFile;
})(eui.Skin);generateEUI.paths['resource/effect/tiangang.exml'] = window.tiangang = (function (_super) {
	__extends(tiangang, _super);
	function tiangang() {
		_super.call(this);
		this.skinParts = ["anim","x1","x2","x3","x4","x5"];
		
		this.height = 64;
		this.width = 150;
		this.anim_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["x1"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, ["x2"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, ["x3"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, ["x4"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, ["x5"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object19,"alpha");
	}
	var _proto = tiangang.prototype;

	_proto.anim_i = function () {
		var t = new egret.tween.TweenGroup();
		this.anim = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i(),this._TweenItem5_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set2_i(),this._Wait1_i(),this._Set3_i(),this._To3_i(),this._To4_i()];
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 500;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set4_i(),this._Wait2_i(),this._Set5_i(),this._To5_i(),this._To6_i()];
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._To6_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set6_i(),this._Wait3_i(),this._Set7_i(),this._To7_i(),this._To8_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 950;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._To7_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._To8_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Set8_i(),this._Wait4_i(),this._Set9_i(),this._To9_i(),this._To10_i()];
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._To9_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._To10_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 64;
		t.width = 150;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.x1_i(),this.x2_i(),this.x3_i(),this.x4_i(),this.x5_i()];
		return t;
	};
	_proto.x1_i = function () {
		var t = new eui.Image();
		this.x1 = t;
		t.scaleX = 0.5;
		t.scaleY = 0.5;
		t.source = "buling_png";
		t.x = 26.2;
		t.y = 34;
		return t;
	};
	_proto.x2_i = function () {
		var t = new eui.Image();
		this.x2 = t;
		t.source = "buling_png";
		t.x = 69;
		t.y = 16;
		return t;
	};
	_proto.x3_i = function () {
		var t = new eui.Image();
		this.x3 = t;
		t.scaleX = 0.8;
		t.scaleY = 0.8;
		t.source = "buling_png";
		t.x = 9;
		t.y = 1;
		return t;
	};
	_proto.x4_i = function () {
		var t = new eui.Image();
		this.x4 = t;
		t.scaleX = 0.5;
		t.scaleY = 0.5;
		t.source = "buling_png";
		t.x = 56;
		t.y = 7;
		return t;
	};
	_proto.x5_i = function () {
		var t = new eui.Image();
		this.x5 = t;
		t.source = "buling_png";
		t.x = 96;
		t.y = -7;
		return t;
	};
	return tiangang;
})(eui.Skin);generateEUI.paths['resource/effect/tianhilight.exml'] = window.tianhilight = (function (_super) {
	__extends(tianhilight, _super);
	function tianhilight() {
		_super.call(this);
		this.skinParts = ["tian","img_bian","img_kuai","group"];
		
		this.height = 250;
		this.width = 350;
		this.tian_i();
		this.elementsContent = [this.group_i()];
		
		eui.Binding.$bindProperties(this, ["img_kuai"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, ["img_bian"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
	}
	var _proto = tianhilight.prototype;

	_proto.tian_i = function () {
		var t = new egret.tween.TweenGroup();
		this.tian = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i(),this._To3_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set2_i(),this._To4_i(),this._To5_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 1750;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 700;
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 250;
		t.width = 350;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.img_bian_i(),this.img_kuai_i()];
		return t;
	};
	_proto.img_bian_i = function () {
		var t = new eui.Image();
		this.img_bian = t;
		t.source = "effect_tian00_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.img_kuai_i = function () {
		var t = new eui.Image();
		this.img_kuai = t;
		t.blendMode = "add";
		t.source = "effect_tian_00_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	return tianhilight;
})(eui.Skin);generateEUI.paths['resource/effect/tongpei.exml'] = window.tongpei = (function (_super) {
	__extends(tongpei, _super);
	function tongpei() {
		_super.call(this);
		this.skinParts = ["tp","image8","image7","image6","image5","image4","image3","image2","image1","image0","image","image15","image14","image13","image12","image11","image10","image9","group"];
		
		this.height = 300;
		this.width = 700;
		this.tp_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, ["image1"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, ["image2"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, ["image3"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, ["image4"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, ["image5"],[0],this._TweenItem7,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, ["image6"],[0],this._TweenItem8,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, ["image7"],[0],this._TweenItem9,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, ["image8"],[0],this._TweenItem10,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, ["image9"],[0],this._TweenItem11,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object33,"alpha");
		eui.Binding.$bindProperties(this, ["image10"],[0],this._TweenItem12,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object34,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object35,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object36,"alpha");
		eui.Binding.$bindProperties(this, ["image11"],[0],this._TweenItem13,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object37,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object38,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object39,"alpha");
		eui.Binding.$bindProperties(this, ["image12"],[0],this._TweenItem14,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object40,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object41,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object42,"alpha");
		eui.Binding.$bindProperties(this, ["image13"],[0],this._TweenItem15,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object43,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object44,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object45,"alpha");
		eui.Binding.$bindProperties(this, ["image14"],[0],this._TweenItem16,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object46,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object47,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object48,"alpha");
		eui.Binding.$bindProperties(this, ["image15"],[0],this._TweenItem17,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object49,"alpha");
		eui.Binding.$bindProperties(this, [9],[],this._Object49,"scaleX");
		eui.Binding.$bindProperties(this, [9],[],this._Object49,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object50,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object50,"scaleX");
		eui.Binding.$bindProperties(this, [1],[],this._Object50,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object51,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object52,"alpha");
	}
	var _proto = tongpei.prototype;

	_proto.tp_i = function () {
		var t = new egret.tween.TweenGroup();
		this.tp = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i(),this._TweenItem5_i(),this._TweenItem6_i(),this._TweenItem7_i(),this._TweenItem8_i(),this._TweenItem9_i(),this._TweenItem10_i(),this._TweenItem11_i(),this._TweenItem12_i(),this._TweenItem13_i(),this._TweenItem14_i(),this._TweenItem15_i(),this._TweenItem16_i(),this._TweenItem17_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._Wait1_i(),this._Set2_i(),this._Wait2_i(),this._Set3_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 350;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set4_i(),this._Wait3_i(),this._Set5_i(),this._Wait4_i(),this._Set6_i()];
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 450;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set7_i(),this._Wait5_i(),this._Set8_i(),this._Wait6_i(),this._Set9_i()];
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 550;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set10_i(),this._Wait7_i(),this._Set11_i(),this._Wait8_i(),this._Set12_i()];
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Set13_i(),this._Wait9_i(),this._Set14_i(),this._Wait10_i(),this._Set15_i()];
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 750;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Set16_i(),this._Wait11_i(),this._Set17_i(),this._Wait12_i(),this._Set18_i()];
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 850;
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._TweenItem7_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem7 = t;
		t.paths = [this._Set19_i(),this._Wait13_i(),this._Set20_i(),this._Wait14_i(),this._Set21_i()];
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 950;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._TweenItem8_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem8 = t;
		t.paths = [this._Set22_i(),this._Wait15_i(),this._Set23_i(),this._Wait16_i(),this._Set24_i()];
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1050;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._TweenItem9_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem9 = t;
		t.paths = [this._Set25_i(),this._Wait17_i(),this._Set26_i(),this._Wait18_i(),this._Set27_i()];
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1150;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto._TweenItem10_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem10 = t;
		t.paths = [this._Set28_i(),this._Wait19_i(),this._Set29_i(),this._Wait20_i(),this._Set30_i()];
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1250;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._TweenItem11_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem11 = t;
		t.paths = [this._Set31_i(),this._Wait21_i(),this._Set32_i(),this._Wait22_i(),this._Set33_i()];
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto._TweenItem12_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem12 = t;
		t.paths = [this._Set34_i(),this._Wait23_i(),this._Set35_i(),this._Wait24_i(),this._Set36_i()];
		return t;
	};
	_proto._Set34_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object34_i();
		return t;
	};
	_proto._Object34_i = function () {
		var t = {};
		this._Object34 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 300;
		return t;
	};
	_proto._Set35_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object35_i();
		return t;
	};
	_proto._Object35_i = function () {
		var t = {};
		this._Object35 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set36_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object36_i();
		return t;
	};
	_proto._Object36_i = function () {
		var t = {};
		this._Object36 = t;
		return t;
	};
	_proto._TweenItem13_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem13 = t;
		t.paths = [this._Set37_i(),this._Wait25_i(),this._Set38_i(),this._Wait26_i(),this._Set39_i()];
		return t;
	};
	_proto._Set37_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object37_i();
		return t;
	};
	_proto._Object37_i = function () {
		var t = {};
		this._Object37 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 350;
		return t;
	};
	_proto._Set38_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object38_i();
		return t;
	};
	_proto._Object38_i = function () {
		var t = {};
		this._Object38 = t;
		return t;
	};
	_proto._Wait26_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set39_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object39_i();
		return t;
	};
	_proto._Object39_i = function () {
		var t = {};
		this._Object39 = t;
		return t;
	};
	_proto._TweenItem14_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem14 = t;
		t.paths = [this._Set40_i(),this._Wait27_i(),this._Set41_i(),this._Wait28_i(),this._Set42_i()];
		return t;
	};
	_proto._Set40_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object40_i();
		return t;
	};
	_proto._Object40_i = function () {
		var t = {};
		this._Object40 = t;
		return t;
	};
	_proto._Wait27_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 400;
		return t;
	};
	_proto._Set41_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object41_i();
		return t;
	};
	_proto._Object41_i = function () {
		var t = {};
		this._Object41 = t;
		return t;
	};
	_proto._Wait28_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set42_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object42_i();
		return t;
	};
	_proto._Object42_i = function () {
		var t = {};
		this._Object42 = t;
		return t;
	};
	_proto._TweenItem15_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem15 = t;
		t.paths = [this._Set43_i(),this._Wait29_i(),this._Set44_i(),this._Wait30_i(),this._Set45_i()];
		return t;
	};
	_proto._Set43_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object43_i();
		return t;
	};
	_proto._Object43_i = function () {
		var t = {};
		this._Object43 = t;
		return t;
	};
	_proto._Wait29_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 450;
		return t;
	};
	_proto._Set44_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object44_i();
		return t;
	};
	_proto._Object44_i = function () {
		var t = {};
		this._Object44 = t;
		return t;
	};
	_proto._Wait30_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set45_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object45_i();
		return t;
	};
	_proto._Object45_i = function () {
		var t = {};
		this._Object45 = t;
		return t;
	};
	_proto._TweenItem16_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem16 = t;
		t.paths = [this._Set46_i(),this._Wait31_i(),this._Set47_i(),this._Wait32_i(),this._Set48_i()];
		return t;
	};
	_proto._Set46_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object46_i();
		return t;
	};
	_proto._Object46_i = function () {
		var t = {};
		this._Object46 = t;
		return t;
	};
	_proto._Wait31_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 500;
		return t;
	};
	_proto._Set47_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object47_i();
		return t;
	};
	_proto._Object47_i = function () {
		var t = {};
		this._Object47 = t;
		return t;
	};
	_proto._Wait32_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set48_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object48_i();
		return t;
	};
	_proto._Object48_i = function () {
		var t = {};
		this._Object48 = t;
		return t;
	};
	_proto._TweenItem17_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem17 = t;
		t.paths = [this._Set49_i(),this._To1_i(),this._Wait33_i(),this._Set50_i(),this._Wait34_i(),this._Set51_i()];
		return t;
	};
	_proto._Set49_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object49_i();
		return t;
	};
	_proto._Object49_i = function () {
		var t = {};
		this._Object49 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object50_i();
		return t;
	};
	_proto._Object50_i = function () {
		var t = {};
		this._Object50 = t;
		return t;
	};
	_proto._Wait33_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set50_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object51_i();
		return t;
	};
	_proto._Object51_i = function () {
		var t = {};
		this._Object51 = t;
		return t;
	};
	_proto._Wait34_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set51_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object52_i();
		return t;
	};
	_proto._Object52_i = function () {
		var t = {};
		this._Object52 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.group_i()];
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.width = 700;
		t.elementsContent = [this.image8_i(),this.image7_i(),this.image6_i(),this.image5_i(),this.image4_i(),this.image3_i(),this.image2_i(),this.image1_i(),this.image0_i(),this.image_i(),this.image15_i(),this.image14_i(),this.image13_i(),this.image12_i(),this.image11_i(),this.image10_i(),this.image9_i()];
		return t;
	};
	_proto.image8_i = function () {
		var t = new eui.Image();
		this.image8 = t;
		t.source = "tongpei_json.tp_09";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image7_i = function () {
		var t = new eui.Image();
		this.image7 = t;
		t.source = "tongpei_json.tp_08";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image6_i = function () {
		var t = new eui.Image();
		this.image6 = t;
		t.source = "tongpei_json.tp_07";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image5_i = function () {
		var t = new eui.Image();
		this.image5 = t;
		t.source = "tongpei_json.tp_06";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image4_i = function () {
		var t = new eui.Image();
		this.image4 = t;
		t.source = "tongpei_json.tp_05";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image3_i = function () {
		var t = new eui.Image();
		this.image3 = t;
		t.source = "tongpei_json.tp_04";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image2_i = function () {
		var t = new eui.Image();
		this.image2 = t;
		t.source = "tongpei_json.tp_03";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image1_i = function () {
		var t = new eui.Image();
		this.image1 = t;
		t.source = "tongpei_json.tp_02";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.source = "tongpei_json.tp_01";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.source = "tongpei_json.tp_00";
		t.x = 200;
		t.y = 6;
		return t;
	};
	_proto.image15_i = function () {
		var t = new eui.Image();
		this.image15 = t;
		t.anchorOffsetX = 165;
		t.anchorOffsetY = 92;
		t.source = "tongpei_json.tp_00";
		t.x = 365;
		t.y = 98;
		return t;
	};
	_proto.image14_i = function () {
		var t = new eui.Image();
		this.image14 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.6";
		t.x = 360;
		t.y = 92;
		return t;
	};
	_proto.image13_i = function () {
		var t = new eui.Image();
		this.image13 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.5";
		t.x = 360;
		t.y = 92;
		return t;
	};
	_proto.image12_i = function () {
		var t = new eui.Image();
		this.image12 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.4";
		t.x = 360;
		t.y = 92;
		return t;
	};
	_proto.image11_i = function () {
		var t = new eui.Image();
		this.image11 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.3";
		t.x = 360;
		t.y = 92;
		return t;
	};
	_proto.image10_i = function () {
		var t = new eui.Image();
		this.image10 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.2";
		t.x = 360;
		t.y = 92;
		return t;
	};
	_proto.image9_i = function () {
		var t = new eui.Image();
		this.image9 = t;
		t.anchorOffsetX = 360;
		t.anchorOffsetY = 105;
		t.blendMode = "add";
		t.rotation = 335.38;
		t.scaleX = 1;
		t.scaleY = 0.5;
		t.source = "tongpei_json.1";
		t.x = 360;
		t.y = 92;
		return t;
	};
	return tongpei;
})(eui.Skin);generateEUI.paths['resource/effect/tongsha.exml'] = window.tongsha = (function (_super) {
	__extends(tongsha, _super);
	function tongsha() {
		_super.call(this);
		this.skinParts = ["tongsha","shang","xia","image12","image11","image10","image9","image8","image7","image6","image5","image4","image3","image2","image1","image0","group"];
		
		this.height = 300;
		this.width = 800;
		this.tongsha_i();
		this.elementsContent = [this._Group1_i()];
		
		eui.Binding.$bindProperties(this, ["shang"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [-455],[],this._Object1,"x");
		eui.Binding.$bindProperties(this, [186],[],this._Object2,"x");
		eui.Binding.$bindProperties(this, ["xia"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [840],[],this._Object3,"x");
		eui.Binding.$bindProperties(this, [166],[],this._Object4,"x");
		eui.Binding.$bindProperties(this, ["image0"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, ["image1"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, ["image2"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, ["image3"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, ["image4"],[0],this._TweenItem7,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, ["image5"],[0],this._TweenItem8,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, ["image6"],[0],this._TweenItem9,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, ["image7"],[0],this._TweenItem10,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, ["image8"],[0],this._TweenItem11,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, ["image9"],[0],this._TweenItem12,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object33,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object34,"alpha");
		eui.Binding.$bindProperties(this, ["image10"],[0],this._TweenItem13,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object35,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object36,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object37,"alpha");
		eui.Binding.$bindProperties(this, ["image11"],[0],this._TweenItem14,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object38,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object39,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object40,"alpha");
		eui.Binding.$bindProperties(this, ["image12"],[0],this._TweenItem15,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object41,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object42,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object43,"alpha");
		eui.Binding.$bindProperties(this, [2],[],this._Object43,"scaleX");
		eui.Binding.$bindProperties(this, [2],[],this._Object43,"scaleY");
	}
	var _proto = tongsha.prototype;

	_proto.tongsha_i = function () {
		var t = new egret.tween.TweenGroup();
		this.tongsha = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i(),this._TweenItem5_i(),this._TweenItem6_i(),this._TweenItem7_i(),this._TweenItem8_i(),this._TweenItem9_i(),this._TweenItem10_i(),this._TweenItem11_i(),this._TweenItem12_i(),this._TweenItem13_i(),this._TweenItem14_i(),this._TweenItem15_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set2_i(),this._To2_i()];
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set3_i(),this._Wait1_i(),this._Set4_i(),this._Wait2_i(),this._Set5_i()];
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 150;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set6_i(),this._Wait3_i(),this._Set7_i(),this._Wait4_i(),this._Set8_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 250;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Set9_i(),this._Wait5_i(),this._Set10_i(),this._Wait6_i(),this._Set11_i()];
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 350;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Set12_i(),this._Wait7_i(),this._Set13_i(),this._Wait8_i(),this._Set14_i()];
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 450;
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._TweenItem7_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem7 = t;
		t.paths = [this._Set15_i(),this._Wait9_i(),this._Set16_i(),this._Wait10_i(),this._Set17_i()];
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 550;
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._TweenItem8_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem8 = t;
		t.paths = [this._Set18_i(),this._Wait11_i(),this._Set19_i(),this._Wait12_i(),this._Set20_i()];
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 650;
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto._TweenItem9_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem9 = t;
		t.paths = [this._Set21_i(),this._Wait13_i(),this._Set22_i(),this._Wait14_i(),this._Set23_i()];
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 750;
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._TweenItem10_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem10 = t;
		t.paths = [this._Set24_i(),this._Wait15_i(),this._Set25_i(),this._Wait16_i(),this._Set26_i()];
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 850;
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._TweenItem11_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem11 = t;
		t.paths = [this._Set27_i(),this._Wait17_i(),this._Set28_i(),this._Wait18_i(),this._Set29_i()];
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 950;
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._TweenItem12_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem12 = t;
		t.paths = [this._Set30_i(),this._Wait19_i(),this._Set31_i(),this._Wait20_i(),this._Set32_i()];
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1050;
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object34_i();
		return t;
	};
	_proto._Object34_i = function () {
		var t = {};
		this._Object34 = t;
		return t;
	};
	_proto._TweenItem13_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem13 = t;
		t.paths = [this._Set33_i(),this._Wait21_i(),this._Set34_i(),this._Wait22_i(),this._Set35_i()];
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object35_i();
		return t;
	};
	_proto._Object35_i = function () {
		var t = {};
		this._Object35 = t;
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1150;
		return t;
	};
	_proto._Set34_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object36_i();
		return t;
	};
	_proto._Object36_i = function () {
		var t = {};
		this._Object36 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set35_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object37_i();
		return t;
	};
	_proto._Object37_i = function () {
		var t = {};
		this._Object37 = t;
		return t;
	};
	_proto._TweenItem14_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem14 = t;
		t.paths = [this._Set36_i(),this._Wait23_i(),this._Set37_i(),this._Wait24_i(),this._Set38_i()];
		return t;
	};
	_proto._Set36_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object38_i();
		return t;
	};
	_proto._Object38_i = function () {
		var t = {};
		this._Object38 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1250;
		return t;
	};
	_proto._Set37_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object39_i();
		return t;
	};
	_proto._Object39_i = function () {
		var t = {};
		this._Object39 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set38_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object40_i();
		return t;
	};
	_proto._Object40_i = function () {
		var t = {};
		this._Object40 = t;
		return t;
	};
	_proto._TweenItem15_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem15 = t;
		t.paths = [this._Set39_i(),this._Wait25_i(),this._Set40_i(),this._To3_i()];
		return t;
	};
	_proto._Set39_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object41_i();
		return t;
	};
	_proto._Object41_i = function () {
		var t = {};
		this._Object41 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1350;
		return t;
	};
	_proto._Set40_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object42_i();
		return t;
	};
	_proto._Object42_i = function () {
		var t = {};
		this._Object42 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 250;
		t.props = this._Object43_i();
		return t;
	};
	_proto._Object43_i = function () {
		var t = {};
		this._Object43 = t;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.group_i()];
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 300;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.visible = false;
		t.width = 800;
		t.elementsContent = [this.shang_i(),this.xia_i(),this.image12_i(),this.image11_i(),this.image10_i(),this.image9_i(),this.image8_i(),this.image7_i(),this.image6_i(),this.image5_i(),this.image4_i(),this.image3_i(),this.image2_i(),this.image1_i(),this.image0_i()];
		return t;
	};
	_proto.shang_i = function () {
		var t = new eui.Image();
		this.shang = t;
		t.source = "tongsha_json.effect_wenzishang";
		t.x = 186;
		t.y = 31;
		return t;
	};
	_proto.xia_i = function () {
		var t = new eui.Image();
		this.xia = t;
		t.source = "tongsha_json.effect_wenzixia";
		t.x = 166;
		t.y = 65;
		return t;
	};
	_proto.image12_i = function () {
		var t = new eui.Image();
		this.image12 = t;
		t.anchorOffsetX = 71;
		t.anchorOffsetY = 61;
		t.blendMode = "add";
		t.source = "tongsha_json.effect_sha";
		t.x = 443;
		t.y = 143;
		return t;
	};
	_proto.image11_i = function () {
		var t = new eui.Image();
		this.image11 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00011";
		t.x = 0;
		t.y = -17;
		return t;
	};
	_proto.image10_i = function () {
		var t = new eui.Image();
		this.image10 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00010";
		t.x = 0;
		t.y = -17;
		return t;
	};
	_proto.image9_i = function () {
		var t = new eui.Image();
		this.image9 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00009";
		t.x = 0;
		t.y = -17;
		return t;
	};
	_proto.image8_i = function () {
		var t = new eui.Image();
		this.image8 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00008";
		t.x = 0;
		t.y = -17;
		return t;
	};
	_proto.image7_i = function () {
		var t = new eui.Image();
		this.image7 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00007";
		t.x = 0;
		t.y = -17;
		return t;
	};
	_proto.image6_i = function () {
		var t = new eui.Image();
		this.image6 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00006";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image5_i = function () {
		var t = new eui.Image();
		this.image5 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00005";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image4_i = function () {
		var t = new eui.Image();
		this.image4 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00004";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image3_i = function () {
		var t = new eui.Image();
		this.image3 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00003";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image2_i = function () {
		var t = new eui.Image();
		this.image2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00002";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image1_i = function () {
		var t = new eui.Image();
		this.image1 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00001";
		t.x = 0;
		t.y = -16;
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tongsha_json.tongsha_00000";
		t.x = 0;
		t.y = -16;
		return t;
	};
	return tongsha;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","horizontalCenter",0),
					new eui.SetProperty("_Image1","verticalCenter",0)
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png"),
					new eui.SetProperty("_Image1","percentWidth",100),
					new eui.SetProperty("_Image1","percentHeight",100),
					new eui.SetProperty("_Image1","horizontalCenter",0),
					new eui.SetProperty("_Image1","verticalCenter",0),
					new eui.SetProperty("_Image1","scaleX",0.8),
					new eui.SetProperty("_Image1","scaleY",0.8)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma 'Microsoft Yahei'";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma 'Microsoft Yahei'";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "UI_common_loading_01_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "UI_common_loading_02_png";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.minHeight = 20;
		this.minWidth = 20;
	}
	var _proto = ScrollerSkin.prototype;

	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.height = 24;
		t.left = "10";
		t.right = "10";
		t.size = 20;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.height = 24;
		t.left = 10;
		t.right = 10;
		t.size = 20;
		t.textColor = 0xa9a9a9;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/AddMoneyAni.exml'] = window.AddMoneyAni = (function (_super) {
	__extends(AddMoneyAni, _super);
	function AddMoneyAni() {
		_super.call(this);
		this.skinParts = ["_txt"];
		
		this.height = 46;
		this.width = 122;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = AddMoneyAni.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.height = 46;
		t.width = 122;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this._txt_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(23,17,21,5);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_manu_bk_01_png";
		t.top = 0;
		t.visible = false;
		return t;
	};
	_proto._txt_i = function () {
		var t = new eui.BitmapLabel();
		this._txt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.font = "bar_plus_font_fnt";
		t.horizontalCenter = 0;
		t.scaleX = 0.8;
		t.scaleY = 0.8;
		t.text = "+1.2345万亿";
		t.verticalCenter = 0;
		return t;
	};
	return AddMoneyAni;
})(eui.Skin);generateEUI.paths['resource/skins/component/DiceView.exml'] = window.DiceViewSkin = (function (_super) {
	__extends(DiceViewSkin, _super);
	function DiceViewSkin() {
		_super.call(this);
		this.skinParts = ["group_dice_anim","lb_dice_num"];
		
		this.height = 308;
		this.width = 408;
		this.elementsContent = [this._Image1_i(),this.group_dice_anim_i(),this.lb_dice_num_i()];
	}
	var _proto = DiceViewSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "TTZ_shaizhong_bg_01_png";
		return t;
	};
	_proto.group_dice_anim_i = function () {
		var t = new eui.Group();
		this.group_dice_anim = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	_proto.lb_dice_num_i = function () {
		var t = new eui.Label();
		this.lb_dice_num = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "Microsoft YaHei";
		t.left = 24;
		t.lineSpacing = 10;
		t.size = 34;
		t.text = "二点";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 40;
		t.wordWrap = true;
		return t;
	};
	return DiceViewSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/MarqueeText.exml'] = window.MarqueeTextSkin = (function (_super) {
	__extends(MarqueeTextSkin, _super);
	function MarqueeTextSkin() {
		_super.call(this);
		this.skinParts = ["label_msg"];
		
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = MarqueeTextSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.left = 0;
		t.right = 0;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.elementsContent = [this.label_msg_i()];
		return t;
	};
	_proto.label_msg_i = function () {
		var t = new eui.Label();
		this.label_msg = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.stroke = 0.5;
		t.strokeColor = 0x3a2222;
		t.text = "初始化";
		t.textAlign = "left";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.wordWrap = false;
		t.x = 0;
		return t;
	};
	return MarqueeTextSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/PlayerListItem.exml'] = window.PlayerListItemSkin = (function (_super) {
	__extends(PlayerListItemSkin, _super);
	function PlayerListItemSkin() {
		_super.call(this);
		this.skinParts = ["playerInfoBg","winInfoBg","headImg","pmIcon","userName","userCoins","playerInfoGroup"];
		
		this.height = 62;
		this.minHeight = 50;
		this.minWidth = 100;
		this.width = 188;
		this.elementsContent = [this.playerInfoGroup_i()];
	}
	var _proto = PlayerListItemSkin.prototype;

	_proto.playerInfoGroup_i = function () {
		var t = new eui.Group();
		this.playerInfoGroup = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.playerInfoBg_i(),this.winInfoBg_i(),this.headImg_i(),this.pmIcon_i(),this.userName_i(),this.userCoins_i(),this._Image1_i()];
		return t;
	};
	_proto.playerInfoBg_i = function () {
		var t = new eui.Image();
		this.playerInfoBg = t;
		t.left = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_allplayers_04_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.winInfoBg_i = function () {
		var t = new eui.Image();
		this.winInfoBg = t;
		t.left = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_allplayersB_1st_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.headImg_i = function () {
		var t = new eui.Image();
		this.headImg = t;
		t.left = 7;
		t.scaleX = 0.4;
		t.scaleY = 0.4;
		t.source = "head_1_png";
		t.verticalCenter = -0.5;
		return t;
	};
	_proto.pmIcon_i = function () {
		var t = new eui.Image();
		this.pmIcon = t;
		t.left = 0;
		t.scaleX = 0.4;
		t.scaleY = 0.4;
		t.source = "pm_icon_first_png";
		t.top = 0;
		return t;
	};
	_proto.userName_i = function () {
		var t = new eui.Label();
		this.userName = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 30;
		t.size = 16;
		t.text = "****0000";
		t.textColor = 0xb2dddc;
		t.verticalCenter = -12;
		t.width = 100;
		return t;
	};
	_proto.userCoins_i = function () {
		var t = new eui.Label();
		this.userCoins = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "Microsoft YaHei";
		t.left = 95;
		t.size = 16;
		t.text = "金：1044";
		t.textColor = 0xF2F2F2;
		t.top = 37;
		t.width = 80;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = -13;
		t.scaleX = 0.8;
		t.scaleY = 0.8;
		t.source = "icon_gold_png";
		t.verticalCenter = 14.5;
		return t;
	};
	return PlayerListItemSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/PlayerView.exml'] = window.PlayerViewSkin = (function (_super) {
	__extends(PlayerViewSkin, _super);
	function PlayerViewSkin() {
		_super.call(this);
		this.skinParts = ["img_head_quan","img_head","coins","nickname","comp_addMoney","playerGroup","noPlayerGroup"];
		
		this.height = 157;
		this.width = 116;
		this.elementsContent = [this.playerGroup_i(),this.noPlayerGroup_i()];
	}
	var _proto = PlayerViewSkin.prototype;

	_proto.playerGroup_i = function () {
		var t = new eui.Group();
		this.playerGroup = t;
		t.height = 157;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 116;
		t.elementsContent = [this._Image1_i(),this.img_head_quan_i(),this._Group2_i(),this._Group3_i(),this._Group4_i(),this.comp_addMoney_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_handB_01_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_head_quan_i = function () {
		var t = new eui.Image();
		this.img_head_quan = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_player_edge_png";
		t.top = 0;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 118;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.width = 118;
		t.elementsContent = [this._Image2_i(),this.img_head_i(),this._Group1_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_player_bg_png";
		t.verticalCenter = 0;
		t.visible = false;
		return t;
	};
	_proto.img_head_i = function () {
		var t = new eui.Image();
		this.img_head = t;
		t.height = 90;
		t.horizontalCenter = 0;
		t.source = "head_1_png";
		t.verticalCenter = 0;
		t.width = 90;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 10.5;
		t.width = 97;
		t.x = 11;
		t.y = 110.67;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image3_i(),this.coins_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 2;
		t.horizontalAlign = "center";
		t.verticalAlign = "contentJustify";
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.height = 18;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_gold_png";
		t.verticalCenter = 0;
		t.width = 18;
		t.x = 5.33;
		return t;
	};
	_proto.coins_i = function () {
		var t = new eui.Label();
		this.coins = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 10.5;
		t.multiline = false;
		t.size = 16;
		t.strokeColor = 0x000000;
		t.text = "99999999";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalCenter = 0;
		t.wordWrap = true;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.horizontalCenter = 0.5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 101;
		t.x = 10;
		t.y = 5;
		t.elementsContent = [this.nickname_i()];
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.borderColor = 0x160101;
		t.fontFamily = "Microsoft YaHei";
		t.height = 18.67;
		t.left = 0;
		t.right = 0;
		t.size = 14;
		t.text = "谁是大赢家";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.verticalCenter = 2.5;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 75;
		t.visible = false;
		t.width = 136;
		t.x = 22;
		t.y = 152;
		t.elementsContent = [this._Image4_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(82,0,5,20);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "bg_gold_png";
		t.top = 0;
		t.width = 0;
		return t;
	};
	_proto.comp_addMoney_i = function () {
		var t = new AddMoney();
		this.comp_addMoney = t;
		t.x = 58;
		t.y = 79;
		return t;
	};
	_proto.noPlayerGroup_i = function () {
		var t = new eui.Group();
		this.noPlayerGroup = t;
		t.anchorOffsetX = 0;
		t.horizontalCenter = 0.5;
		t.verticalCenter = 1.5;
		t.visible = false;
		t.width = 101;
		t.elementsContent = [this._Image5_i(),this._Image6_i(),this._Image7_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_player_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "icon_player_empty_png";
		t.top = 0;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_player_edge_png";
		t.top = 0;
		return t;
	};
	return PlayerViewSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/ProgressBar.exml'] = window.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.height = 30;
		this.width = 100;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(25,0,187,40);
		t.source = "UI_TTZ_bankertotal_01_png";
		t.top = 0;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 5;
		t.fillMode = "clip";
		t.left = 3;
		t.right = 3;
		t.scale9Grid = new egret.Rectangle(14,7,201,16);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_bankertotal_02_png";
		t.top = 4;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.visible = false;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/skins/component/test.exml'] = window.test = (function (_super) {
	__extends(test, _super);
	function test() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 300;
		this.width = 400;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = test.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._BitmapLabel1_i()];
		return t;
	};
	_proto._BitmapLabel1_i = function () {
		var t = new eui.BitmapLabel();
		t.bottom = 0;
		t.font = "bar_plus_font_fnt";
		t.left = 0;
		t.right = 0;
		t.text = "1.2万";
		t.top = 0;
		return t;
	};
	return test;
})(eui.Skin);generateEUI.paths['resource/skins/component/Toast.exml'] = window.ToastSkin = (function (_super) {
	__extends(ToastSkin, _super);
	function ToastSkin() {
		_super.call(this);
		this.skinParts = ["label_text","view"];
		
		this.height = 720;
		this.width = 1280;
		this.elementsContent = [this._Image1_i(),this._Group1_i()];
	}
	var _proto = ToastSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "underlayment_png";
		t.top = 0;
		t.visible = false;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.elementsContent = [this.view_i()];
		return t;
	};
	_proto.view_i = function () {
		var t = new eui.Group();
		this.view = t;
		t.horizontalCenter = 1;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.y = 329;
		t.elementsContent = [this._Image2_i(),this.label_text_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(30,12,186,15);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "bg_toast_png";
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.label_text_i = function () {
		var t = new eui.Label();
		this.label_text = t;
		t.bottom = 20;
		t.fontFamily = "Microsoft YaHei";
		t.left = 20;
		t.right = 20;
		t.size = 20;
		t.text = "提示消息Toast";
		t.textAlign = "center";
		t.top = 18;
		t.touchEnabled = false;
		t.verticalAlign = "middle";
		return t;
	};
	return ToastSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/hallScene/ErbaHistory.exml'] = window.ErbaHistorySkin = (function (_super) {
	__extends(ErbaHistorySkin, _super);
	function ErbaHistorySkin() {
		_super.call(this);
		this.skinParts = ["bg","cardList","resultNum4","resultNum1","resultNum2","resultNum3","resultNumGroup"];
		
		this.height = 157;
		this.width = 344;
		this.elementsContent = [this.bg_i(),this._Scroller1_i(),this.resultNumGroup_i()];
	}
	var _proto = ErbaHistorySkin.prototype;

	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_history_01_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 140;
		t.horizontalCenter = 40.5;
		t.rotation = 0;
		t.scrollPolicyH = "off";
		t.scrollPolicyV = "off";
		t.verticalCenter = 0;
		t.width = 245;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetY = 0;
		t.x = 0;
		t.y = 50.57;
		t.elementsContent = [this.cardList_i()];
		return t;
	};
	_proto.cardList_i = function () {
		var t = new eui.List();
		this.cardList = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.itemRenderer = ErbaHistoryItem;
		t.itemRendererSkinName = ErbaHistoryItemSkin;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.layout = this._TileLayout1_i();
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._TileLayout1_i = function () {
		var t = new eui.TileLayout();
		t.columnAlign = "left";
		t.columnWidth = 58;
		t.horizontalAlign = "center";
		t.horizontalGap = 4;
		t.orientation = "columns";
		t.paddingLeft = 0;
		t.paddingRight = 0;
		t.paddingTop = 4;
		t.requestedColumnCount = 4;
		t.requestedRowCount = 4;
		t.rowAlign = "top";
		t.rowHeight = 29;
		t.verticalAlign = "middle";
		t.verticalGap = 5;
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i(),this._Object2_i(),this._Object3_i(),this._Object4_i(),this._Object5_i(),this._Object6_i(),this._Object7_i(),this._Object8_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto.resultNumGroup_i = function () {
		var t = new eui.Group();
		this.resultNumGroup = t;
		t.anchorOffsetY = 0;
		t.height = 136;
		t.horizontalCenter = -103;
		t.verticalCenter = 0;
		t.width = 30;
		t.elementsContent = [this.resultNum4_i(),this.resultNum1_i(),this.resultNum2_i(),this.resultNum3_i()];
		return t;
	};
	_proto.resultNum4_i = function () {
		var t = new eui.Label();
		this.resultNum4 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 22;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x5dcdcd;
		t.verticalAlign = "middle";
		t.verticalCenter = -51;
		return t;
	};
	_proto.resultNum1_i = function () {
		var t = new eui.Label();
		this.resultNum1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 22;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x5dcdcd;
		t.verticalAlign = "middle";
		t.verticalCenter = -18;
		return t;
	};
	_proto.resultNum2_i = function () {
		var t = new eui.Label();
		this.resultNum2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 22;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x5dcdcd;
		t.verticalAlign = "middle";
		t.verticalCenter = 16;
		return t;
	};
	_proto.resultNum3_i = function () {
		var t = new eui.Label();
		this.resultNum3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 22;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x5dcdcd;
		t.verticalAlign = "middle";
		t.verticalCenter = 52;
		return t;
	};
	return ErbaHistorySkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/gameScene/ErbaGameScene.exml'] = window.ErbaGameSceneSkin = (function (_super) {
	__extends(ErbaGameSceneSkin, _super);
	var ErbaGameSceneSkin$Skin1 = 	(function (_super) {
		__extends(ErbaGameSceneSkin$Skin1, _super);
		function ErbaGameSceneSkin$Skin1() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ErbaGameSceneSkin$Skin1.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "UI_manu_button_08_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ErbaGameSceneSkin$Skin1;
	})(eui.Skin);

	function ErbaGameSceneSkin() {
		_super.call(this);
		this.skinParts = ["img_dealer_head","label_banker_gold","g_zhuang","label_timer","g_block","label_toplimit","label_banker_earnings","label_self_earnings","g_limit","desk_ui","img_mj_wall_pos32","img_mj_wall_pos31","img_mj_wall_pos30","img_mj_wall_pos29","img_mj_wall_pos28","img_mj_wall_pos27","img_mj_wall_pos26","img_mj_wall_pos25","img_mj_wall_pos24","img_mj_wall_pos23","img_mj_wall_pos22","img_mj_wall_pos21","img_mj_wall_pos20","img_mj_wall_pos19","img_mj_wall_pos18","img_mj_wall_pos17","img_mj_wall_pos16","img_mj_wall_pos15","img_mj_wall_pos14","img_mj_wall_pos13","img_mj_wall_pos12","img_mj_wall_pos11","img_mj_wall_pos10","img_mj_wall_pos9","img_mj_wall_pos8","img_mj_wall_pos7","img_mj_wall_pos6","img_mj_wall_pos5","img_mj_wall_pos4","img_mj_wall_pos3","img_mj_wall_pos2","img_mj_wall_pos1","_wall","effect_mj_pos4","pai_pos4_1","pai_pos4_2","_pos4","effect_mj_pos1","pai_pos1_1","pai_pos1_2","_pos1","effect_mj_pos2","pai_pos2_1","pai_pos2_2","_pos2","effect_mj_pos3","pai_pos3_2","pai_pos3_1","_pos3","playerview_1","playerview_2","playerview_3","playerview_4","playerview_5","playerview_other","g_other_head","_playerview","progress_bet_gold","label_banker_gold_progress","g_chips_pos1","g_chips_pos2","g_chips_pos3","label_betpos_tip_1","label_betpos_tip_2","label_betpos_tip_3","result_tip_pos1_img","result_tip_pos1_text","result_effect_tiangang_1","result_tip_pos1","result_tip_pos2_img","result_tip_pos2_text","result_effect_tiangang_2","result_tip_pos2","result_tip_pos3_img","result_tip_pos3_text","result_effect_tiangang_3","result_tip_pos3","result_tip_pos4_img","result_tip_pos4_text","result_tip_pos4","result_effect_tiangang_4","_resultTip","effect_statetip","effct_tongsha","effect_tongpei","effect_betpos1","effect_betpos2","effect_betpos3","g_effect","g_dice","rect_shun","rect_tian","rect_di","g_click","desk_ui_top","group_desk","label_my_nickname","label_my_gold","label_my_bet_titile","label_bet_gold","img_my_head","my_addMoney","head_panel","img_chip_1","img_light_1","label_chip1","chip_1","img_chip_2","img_light_2","label_chip2","chip_2","img_chip_3","img_light_3","label_chip3","chip_3","img_chip_4","img_light_4","label_chip4","chip_4","img_chip_5","img_light_5","label_chip5","chip_5","_chip","right","history","_ui","g_fly_layer","btn_menu","menu","label_game_num","img_playerlist","playerlist","group_playerlist","dice_view","top"];
		
		this.height = 720;
		this.width = 1280;
		this.elementsContent = [this._Image1_i(),this.group_desk_i(),this._ui_i(),this.g_fly_layer_i(),this.top_i()];
	}
	var _proto = ErbaGameSceneSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = -1;
		t.right = 1;
		t.source = "UI_TTZ_BG_01_jpg";
		t.top = 0;
		return t;
	};
	_proto.group_desk_i = function () {
		var t = new eui.Group();
		this.group_desk = t;
		t.height = 921;
		t.horizontalCenter = 0;
		t.touchThrough = true;
		t.verticalCenter = 30;
		t.width = 1711;
		t.elementsContent = [this._Image2_i(),this.desk_ui_i(),this._wall_i(),this._pos4_i(),this._pos1_i(),this._pos2_i(),this._pos3_i(),this._playerview_i(),this.desk_ui_top_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1000;
		t.horizontalCenter = 0.5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_table_01_png";
		t.verticalCenter = 29.5;
		t.width = 1632;
		return t;
	};
	_proto.desk_ui_i = function () {
		var t = new eui.Group();
		this.desk_ui = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.g_zhuang_i(),this.g_block_i(),this.g_limit_i()];
		return t;
	};
	_proto.g_zhuang_i = function () {
		var t = new eui.Group();
		this.g_zhuang = t;
		t.anchorOffsetY = 0;
		t.height = 135;
		t.horizontalCenter = 0.5;
		t.y = 84.31;
		t.elementsContent = [this._Image3_i(),this.img_dealer_head_i(),this._Label1_i(),this.label_banker_gold_i(),this._Image4_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.source = "UI_TTZ_bankerhand_01_png";
		t.top = 0;
		t.width = 118;
		t.x = 0;
		return t;
	};
	_proto.img_dealer_head_i = function () {
		var t = new eui.Image();
		this.img_dealer_head = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 106;
		t.source = "UI_TTZ_bankerhand_02_png";
		t.width = 106;
		t.x = 6;
		t.y = 22.4;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.horizontalCenter = 0;
		t.size = 16;
		t.text = "庄家";
		t.textColor = 0xffd403;
		t.y = 6.33;
		return t;
	};
	_proto.label_banker_gold_i = function () {
		var t = new eui.Label();
		this.label_banker_gold = t;
		t.horizontalCenter = 8;
		t.size = 20;
		t.text = "9999999";
		t.textColor = 0xffffff;
		t.visible = false;
		t.y = 132.98;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.height = 20;
		t.source = "icon_gold_png";
		t.visible = false;
		t.width = 20;
		t.x = 7;
		t.y = 133;
		return t;
	};
	_proto.g_block_i = function () {
		var t = new eui.Group();
		this.g_block = t;
		t.height = 63;
		t.width = 72;
		t.x = 722.33;
		t.y = 165.33;
		t.elementsContent = [this._Image5_i(),this.label_timer_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_timer_01_png";
		t.top = 0;
		return t;
	};
	_proto.label_timer_i = function () {
		var t = new eui.Label();
		this.label_timer = t;
		t.anchorOffsetX = 16;
		t.anchorOffsetY = 12;
		t.size = 24;
		t.text = "99";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 32;
		t.x = 31.5;
		t.y = 30.34;
		return t;
	};
	_proto.g_limit_i = function () {
		var t = new eui.Group();
		this.g_limit = t;
		t.anchorOffsetX = 0;
		t.width = 165;
		t.x = 527;
		t.y = 135;
		t.elementsContent = [this._Label2_i(),this._Label3_i(),this._Label4_i(),this.label_toplimit_i(),this.label_banker_earnings_i(),this.label_self_earnings_i()];
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "限红：";
		t.textColor = 0x888888;
		t.width = 52.5;
		t.x = 31.57;
		t.y = 0;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.size = 16;
		t.text = "庄家收益：";
		t.textAlign = "right";
		t.textColor = 0x888888;
		t.x = 0;
		t.y = 22;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.size = 16;
		t.text = "个人收益：";
		t.textAlign = "right";
		t.textColor = 0x888888;
		t.x = 0;
		t.y = 46;
		return t;
	};
	_proto.label_toplimit_i = function () {
		var t = new eui.Label();
		this.label_toplimit = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "200-2.5千";
		t.textAlign = "left";
		t.textColor = 0x32c1cd;
		t.width = 90;
		t.x = 74;
		t.y = 0;
		return t;
	};
	_proto.label_banker_earnings_i = function () {
		var t = new eui.Label();
		this.label_banker_earnings = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "99.99万";
		t.textAlign = "left";
		t.textColor = 0x32c1cd;
		t.width = 90;
		t.x = 74;
		t.y = 23;
		return t;
	};
	_proto.label_self_earnings_i = function () {
		var t = new eui.Label();
		this.label_self_earnings = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "99.99万";
		t.textAlign = "left";
		t.textColor = 0x32c1cd;
		t.width = 87.5;
		t.x = 75.25;
		t.y = 46;
		return t;
	};
	_proto._wall_i = function () {
		var t = new eui.Group();
		this._wall = t;
		t.x = 1012.06;
		t.y = 226.49;
		t.elementsContent = [this._Group9_i(),this._Group18_i()];
		return t;
	};
	_proto._Group9_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52.01;
		t.width = 219.33;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Group1_i(),this._Group2_i(),this._Group3_i(),this._Group4_i(),this._Group5_i(),this._Group6_i(),this._Group7_i(),this._Group8_i()];
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 179.86;
		t.y = 1.34;
		t.elementsContent = [this.img_mj_wall_pos32_i(),this.img_mj_wall_pos31_i()];
		return t;
	};
	_proto.img_mj_wall_pos32_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos32 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos31_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos31 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.x = 154.5;
		t.y = 1.32;
		t.elementsContent = [this.img_mj_wall_pos30_i(),this.img_mj_wall_pos29_i()];
		return t;
	};
	_proto.img_mj_wall_pos30_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos30 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos29_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos29 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.x = 128.54;
		t.y = 1.37;
		t.elementsContent = [this.img_mj_wall_pos28_i(),this.img_mj_wall_pos27_i()];
		return t;
	};
	_proto.img_mj_wall_pos28_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos28 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos27_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos27 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.x = 103.18;
		t.y = 1.35;
		t.elementsContent = [this.img_mj_wall_pos26_i(),this.img_mj_wall_pos25_i()];
		return t;
	};
	_proto.img_mj_wall_pos26_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos26 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos25_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos25 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.x = 77.17;
		t.y = 1.32;
		t.elementsContent = [this.img_mj_wall_pos24_i(),this.img_mj_wall_pos23_i()];
		return t;
	};
	_proto.img_mj_wall_pos24_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos24 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos23_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos23 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.x = 51.81;
		t.y = 1.3;
		t.elementsContent = [this.img_mj_wall_pos22_i(),this.img_mj_wall_pos21_i()];
		return t;
	};
	_proto.img_mj_wall_pos22_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos22 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos21_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos21 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group7_i = function () {
		var t = new eui.Group();
		t.x = 25.85;
		t.y = 1.35;
		t.elementsContent = [this.img_mj_wall_pos20_i(),this.img_mj_wall_pos19_i()];
		return t;
	};
	_proto.img_mj_wall_pos20_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos20 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos19_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos19 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group8_i = function () {
		var t = new eui.Group();
		t.x = 0.49;
		t.y = 1.33;
		t.elementsContent = [this.img_mj_wall_pos18_i(),this.img_mj_wall_pos17_i()];
		return t;
	};
	_proto.img_mj_wall_pos18_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos18 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos17_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos17 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group18_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52.01;
		t.width = 219.33;
		t.x = 5.37;
		t.y = 24.04;
		t.elementsContent = [this._Group10_i(),this._Group11_i(),this._Group12_i(),this._Group13_i(),this._Group14_i(),this._Group15_i(),this._Group16_i(),this._Group17_i()];
		return t;
	};
	_proto._Group10_i = function () {
		var t = new eui.Group();
		t.x = 179.86;
		t.y = 1.34;
		t.elementsContent = [this.img_mj_wall_pos16_i(),this.img_mj_wall_pos15_i()];
		return t;
	};
	_proto.img_mj_wall_pos16_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos16 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos15_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos15 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group11_i = function () {
		var t = new eui.Group();
		t.x = 154.5;
		t.y = 1.32;
		t.elementsContent = [this.img_mj_wall_pos14_i(),this.img_mj_wall_pos13_i()];
		return t;
	};
	_proto.img_mj_wall_pos14_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos14 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos13_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos13 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group12_i = function () {
		var t = new eui.Group();
		t.x = 128.54;
		t.y = 1.37;
		t.elementsContent = [this.img_mj_wall_pos12_i(),this.img_mj_wall_pos11_i()];
		return t;
	};
	_proto.img_mj_wall_pos12_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos12 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos11_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos11 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group13_i = function () {
		var t = new eui.Group();
		t.x = 103.18;
		t.y = 1.35;
		t.elementsContent = [this.img_mj_wall_pos10_i(),this.img_mj_wall_pos9_i()];
		return t;
	};
	_proto.img_mj_wall_pos10_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos10 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos9_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos9 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group14_i = function () {
		var t = new eui.Group();
		t.x = 77.17;
		t.y = 1.32;
		t.elementsContent = [this.img_mj_wall_pos8_i(),this.img_mj_wall_pos7_i()];
		return t;
	};
	_proto.img_mj_wall_pos8_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos8 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos7_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos7 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group15_i = function () {
		var t = new eui.Group();
		t.x = 51.81;
		t.y = 1.3;
		t.elementsContent = [this.img_mj_wall_pos6_i(),this.img_mj_wall_pos5_i()];
		return t;
	};
	_proto.img_mj_wall_pos6_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos6 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos5_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos5 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group16_i = function () {
		var t = new eui.Group();
		t.x = 25.85;
		t.y = 1.35;
		t.elementsContent = [this.img_mj_wall_pos4_i(),this.img_mj_wall_pos3_i()];
		return t;
	};
	_proto.img_mj_wall_pos4_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos4 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos3_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos3 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._Group17_i = function () {
		var t = new eui.Group();
		t.x = 0.49;
		t.y = 1.33;
		t.elementsContent = [this.img_mj_wall_pos2_i(),this.img_mj_wall_pos1_i()];
		return t;
	};
	_proto.img_mj_wall_pos2_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos2 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 0;
		t.y = 11.97;
		return t;
	};
	_proto.img_mj_wall_pos1_i = function () {
		var t = new eui.Image();
		this.img_mj_wall_pos1 = t;
		t.scaleX = 0.66;
		t.scaleY = 0.66;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 2.01;
		t.y = 0;
		return t;
	};
	_proto._pos4_i = function () {
		var t = new eui.Group();
		this._pos4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60;
		t.width = 115;
		t.x = 800.12;
		t.y = 246.57;
		t.elementsContent = [this.effect_mj_pos4_i(),this.pai_pos4_1_i(),this.pai_pos4_2_i()];
		return t;
	};
	_proto.effect_mj_pos4_i = function () {
		var t = new Effect_MJPos_4();
		this.effect_mj_pos4 = t;
		t.x = -43;
		t.y = -18;
		return t;
	};
	_proto.pai_pos4_1_i = function () {
		var t = new eui.Image();
		this.pai_pos4_1 = t;
		t.scaleX = 0.83;
		t.scaleY = 0.83;
		t.source = "UI_TTZ_majiang_B2_png";
		t.x = 21;
		t.y = 2;
		return t;
	};
	_proto.pai_pos4_2_i = function () {
		var t = new eui.Image();
		this.pai_pos4_2 = t;
		t.scaleX = 0.83;
		t.scaleY = 0.83;
		t.source = "UI_TTZ_majiang_B2_png";
		t.x = 54;
		t.y = 2;
		return t;
	};
	_proto._pos1_i = function () {
		var t = new eui.Group();
		this._pos1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60;
		t.width = 110.45;
		t.x = 492.82;
		t.y = 513.72;
		t.elementsContent = [this.effect_mj_pos1_i(),this.pai_pos1_1_i(),this.pai_pos1_2_i()];
		return t;
	};
	_proto.effect_mj_pos1_i = function () {
		var t = new Effect_MJPos_1();
		this.effect_mj_pos1 = t;
		t.x = -47.56;
		t.y = -18.07;
		return t;
	};
	_proto.pai_pos1_1_i = function () {
		var t = new eui.Image();
		this.pai_pos1_1 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B1_png";
		t.x = 7;
		t.y = 2;
		return t;
	};
	_proto.pai_pos1_2_i = function () {
		var t = new eui.Image();
		this.pai_pos1_2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B1_png";
		t.x = 46;
		t.y = 2;
		return t;
	};
	_proto._pos2_i = function () {
		var t = new eui.Group();
		this._pos2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60;
		t.width = 110.45;
		t.x = 800.67;
		t.y = 513.79;
		t.elementsContent = [this.effect_mj_pos2_i(),this.pai_pos2_1_i(),this.pai_pos2_2_i()];
		return t;
	};
	_proto.effect_mj_pos2_i = function () {
		var t = new Effect_MJPos_2();
		this.effect_mj_pos2 = t;
		t.x = -45.4;
		t.y = -18;
		return t;
	};
	_proto.pai_pos2_1_i = function () {
		var t = new eui.Image();
		this.pai_pos2_1 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B2_png";
		t.x = 13.72;
		t.y = 2.34;
		return t;
	};
	_proto.pai_pos2_2_i = function () {
		var t = new eui.Image();
		this.pai_pos2_2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B2_png";
		t.x = 54;
		t.y = 2.34;
		return t;
	};
	_proto._pos3_i = function () {
		var t = new eui.Group();
		this._pos3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60;
		t.width = 110.45;
		t.x = 1111.06;
		t.y = 515.65;
		t.elementsContent = [this.effect_mj_pos3_i(),this.pai_pos3_2_i(),this.pai_pos3_1_i()];
		return t;
	};
	_proto.effect_mj_pos3_i = function () {
		var t = new Effect_MJPos_3();
		this.effect_mj_pos3 = t;
		t.x = -43.67;
		t.y = -17.34;
		return t;
	};
	_proto.pai_pos3_2_i = function () {
		var t = new eui.Image();
		this.pai_pos3_2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 49.5;
		t.y = 0.6;
		return t;
	};
	_proto.pai_pos3_1_i = function () {
		var t = new eui.Image();
		this.pai_pos3_1 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_majiang_B3_png";
		t.x = 11;
		t.y = 0.82;
		return t;
	};
	_proto._playerview_i = function () {
		var t = new eui.Group();
		this._playerview = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.touchThrough = true;
		t.elementsContent = [this.playerview_1_i(),this.playerview_2_i(),this.playerview_3_i(),this.playerview_4_i(),this.playerview_5_i(),this.g_other_head_i()];
		return t;
	};
	_proto.playerview_1_i = function () {
		var t = new PlayerView();
		this.playerview_1 = t;
		t.horizontalCenter = -475.5;
		t.skinName = "PlayerViewSkin";
		t.verticalCenter = -253;
		return t;
	};
	_proto.playerview_2_i = function () {
		var t = new PlayerView();
		this.playerview_2 = t;
		t.horizontalCenter = -575.5;
		t.skinName = "PlayerViewSkin";
		t.verticalCenter = -75;
		return t;
	};
	_proto.playerview_3_i = function () {
		var t = new PlayerView();
		this.playerview_3 = t;
		t.horizontalCenter = 545.5;
		t.skinName = "PlayerViewSkin";
		t.verticalCenter = 115;
		return t;
	};
	_proto.playerview_4_i = function () {
		var t = new PlayerView();
		this.playerview_4 = t;
		t.horizontalCenter = 573.5;
		t.skinName = "PlayerViewSkin";
		t.verticalCenter = -76;
		return t;
	};
	_proto.playerview_5_i = function () {
		var t = new PlayerView();
		this.playerview_5 = t;
		t.horizontalCenter = 473.5;
		t.skinName = "PlayerViewSkin";
		t.verticalCenter = -252;
		return t;
	};
	_proto.g_other_head_i = function () {
		var t = new eui.Group();
		this.g_other_head = t;
		t.height = 100;
		t.horizontalCenter = -540.5;
		t.verticalCenter = 97.5;
		t.width = 100;
		t.elementsContent = [this.playerview_other_i()];
		return t;
	};
	_proto.playerview_other_i = function () {
		var t = new eui.Image();
		this.playerview_other = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_otherP_01_png";
		return t;
	};
	_proto.desk_ui_top_i = function () {
		var t = new eui.Group();
		this.desk_ui_top = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.touchThrough = true;
		t.elementsContent = [this._Group19_i(),this.g_chips_pos1_i(),this.g_chips_pos2_i(),this.g_chips_pos3_i(),this._Group20_i(),this._resultTip_i(),this.g_effect_i(),this.g_dice_i(),this.g_click_i()];
		return t;
	};
	_proto._Group19_i = function () {
		var t = new eui.Group();
		t.x = 921.3;
		t.y = 184.22;
		t.elementsContent = [this.progress_bet_gold_i(),this._Image6_i(),this.label_banker_gold_progress_i()];
		return t;
	};
	_proto.progress_bet_gold_i = function () {
		var t = new Component.ProgressBar();
		this.progress_bet_gold = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37.2;
		t.skinName = "ProgressBarSkin";
		t.value = 0;
		t.width = 207.5;
		t.x = 0;
		t.y = -3.2;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.height = 20;
		t.left = 8;
		t.source = "icon_gold_png";
		t.verticalCenter = -1;
		t.width = 20;
		return t;
	};
	_proto.label_banker_gold_progress_i = function () {
		var t = new eui.Label();
		this.label_banker_gold_progress = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 24.8;
		t.size = 18;
		t.stroke = 0.3;
		t.text = "5.1242万 / 6.123万";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 162.6;
		t.x = 35.45;
		t.y = 3.73;
		return t;
	};
	_proto.g_chips_pos1_i = function () {
		var t = new eui.Group();
		this.g_chips_pos1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 144;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.width = 241;
		t.x = 456;
		t.y = 320;
		return t;
	};
	_proto.g_chips_pos2_i = function () {
		var t = new eui.Group();
		this.g_chips_pos2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 148;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.width = 246;
		t.x = 732;
		t.y = 318;
		return t;
	};
	_proto.g_chips_pos3_i = function () {
		var t = new eui.Group();
		this.g_chips_pos3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 147.33;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.width = 239;
		t.x = 1014;
		t.y = 318;
		return t;
	};
	_proto._Group20_i = function () {
		var t = new eui.Group();
		t.touchEnabled = false;
		t.x = 520.28;
		t.y = 465;
		t.elementsContent = [this._Image7_i(),this._Image8_i(),this._Image9_i(),this.label_betpos_tip_1_i(),this.label_betpos_tip_2_i(),this.label_betpos_tip_3_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "UI_TTZ_playertotal_02_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "UI_TTZ_playertotal_02_png";
		t.x = 307.32;
		t.y = 0;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.source = "UI_TTZ_playertotal_02_png";
		t.x = 606.7;
		t.y = 0;
		return t;
	};
	_proto.label_betpos_tip_1_i = function () {
		var t = new eui.Label();
		this.label_betpos_tip_1 = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "8.52千 / 200";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = -3.5;
		t.width = 151.5;
		t.x = 11.5;
		return t;
	};
	_proto.label_betpos_tip_2_i = function () {
		var t = new eui.Label();
		this.label_betpos_tip_2 = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "8.52千 / 200";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = -3.5;
		t.width = 151.5;
		t.x = 318.11;
		return t;
	};
	_proto.label_betpos_tip_3_i = function () {
		var t = new eui.Label();
		this.label_betpos_tip_3 = t;
		t.anchorOffsetX = 0;
		t.size = 16;
		t.text = "8.52千 / 200";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = -3.5;
		t.width = 151.5;
		t.x = 615.47;
		return t;
	};
	_proto._resultTip_i = function () {
		var t = new eui.Group();
		this._resultTip = t;
		t.touchChildren = false;
		t.touchThrough = true;
		t.x = 598;
		t.y = 244.65;
		t.elementsContent = [this.result_tip_pos1_i(),this.result_tip_pos2_i(),this.result_tip_pos3_i(),this.result_tip_pos4_i(),this.result_effect_tiangang_4_i()];
		return t;
	};
	_proto.result_tip_pos1_i = function () {
		var t = new eui.Group();
		this.result_tip_pos1 = t;
		t.x = 0;
		t.y = 270.69;
		t.elementsContent = [this.result_tip_pos1_img_i(),this.result_tip_pos1_text_i(),this.result_effect_tiangang_1_i()];
		return t;
	};
	_proto.result_tip_pos1_img_i = function () {
		var t = new eui.Image();
		this.result_tip_pos1_img = t;
		t.source = "UI_TTZ_result_tip_1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.result_tip_pos1_text_i = function () {
		var t = new eui.Label();
		this.result_tip_pos1_text = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 29.33;
		t.size = 24;
		t.text = "七点半";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 94;
		t.x = 16.7;
		t.y = 10.32;
		return t;
	};
	_proto.result_effect_tiangang_1_i = function () {
		var t = new Effect_tiangang();
		this.result_effect_tiangang_1 = t;
		t.x = -4;
		t.y = -8;
		return t;
	};
	_proto.result_tip_pos2_i = function () {
		var t = new eui.Group();
		this.result_tip_pos2 = t;
		t.x = 308.58;
		t.y = 271.35;
		t.elementsContent = [this.result_tip_pos2_img_i(),this.result_tip_pos2_text_i(),this.result_effect_tiangang_2_i()];
		return t;
	};
	_proto.result_tip_pos2_img_i = function () {
		var t = new eui.Image();
		this.result_tip_pos2_img = t;
		t.source = "UI_TTZ_result_tip_1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.result_tip_pos2_text_i = function () {
		var t = new eui.Label();
		this.result_tip_pos2_text = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 28;
		t.size = 24;
		t.text = "七点半";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 94;
		t.x = 16.7;
		t.y = 10.32;
		return t;
	};
	_proto.result_effect_tiangang_2_i = function () {
		var t = new Effect_tiangang();
		this.result_effect_tiangang_2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = -10.58;
		t.y = -8.66;
		return t;
	};
	_proto.result_tip_pos3_i = function () {
		var t = new eui.Group();
		this.result_tip_pos3 = t;
		t.x = 619.82;
		t.y = 270.68;
		t.elementsContent = [this.result_tip_pos3_img_i(),this.result_tip_pos3_text_i(),this.result_effect_tiangang_3_i()];
		return t;
	};
	_proto.result_tip_pos3_img_i = function () {
		var t = new eui.Image();
		this.result_tip_pos3_img = t;
		t.source = "UI_TTZ_result_tip_1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.result_tip_pos3_text_i = function () {
		var t = new eui.Label();
		this.result_tip_pos3_text = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 29.33;
		t.size = 24;
		t.text = "七点半";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 94;
		t.x = 16.7;
		t.y = 10.32;
		return t;
	};
	_proto.result_effect_tiangang_3_i = function () {
		var t = new Effect_tiangang();
		this.result_effect_tiangang_3 = t;
		t.x = -9;
		t.y = -9;
		return t;
	};
	_proto.result_tip_pos4_i = function () {
		var t = new eui.Group();
		this.result_tip_pos4 = t;
		t.x = 301.83;
		t.y = 0.7;
		t.elementsContent = [this.result_tip_pos4_img_i(),this.result_tip_pos4_text_i()];
		return t;
	};
	_proto.result_tip_pos4_img_i = function () {
		var t = new eui.Image();
		this.result_tip_pos4_img = t;
		t.source = "UI_TTZ_result_tip_1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.result_tip_pos4_text_i = function () {
		var t = new eui.Label();
		this.result_tip_pos4_text = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 26.67;
		t.size = 24;
		t.text = "七点半";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 94;
		t.x = 16.7;
		t.y = 10.32;
		return t;
	};
	_proto.result_effect_tiangang_4_i = function () {
		var t = new Effect_tiangang();
		this.result_effect_tiangang_4 = t;
		t.x = 291;
		t.y = -9;
		return t;
	};
	_proto.g_effect_i = function () {
		var t = new eui.Group();
		this.g_effect = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.effect_statetip_i(),this.effct_tongsha_i(),this.effect_tongpei_i(),this.effect_betpos1_i(),this.effect_betpos2_i(),this.effect_betpos3_i()];
		return t;
	};
	_proto.effect_statetip_i = function () {
		var t = new StateTipEffect();
		this.effect_statetip = t;
		t.height = 250;
		t.horizontalCenter = 0;
		t.verticalCenter = -50;
		t.width = 350;
		return t;
	};
	_proto.effct_tongsha_i = function () {
		var t = new Effect_TongSha();
		this.effct_tongsha = t;
		t.height = 300;
		t.horizontalCenter = 0;
		t.verticalCenter = -50;
		t.width = 800;
		return t;
	};
	_proto.effect_tongpei_i = function () {
		var t = new Effect_TongPei();
		this.effect_tongpei = t;
		t.height = 300;
		t.horizontalCenter = 0;
		t.verticalCenter = -50;
		t.width = 700;
		return t;
	};
	_proto.effect_betpos1_i = function () {
		var t = new Effect_betpos_1();
		this.effect_betpos1 = t;
		t.height = 250;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 350;
		t.x = 389.83;
		t.y = 281.3;
		return t;
	};
	_proto.effect_betpos2_i = function () {
		var t = new Effect_betpos_2();
		this.effect_betpos2 = t;
		t.height = 250;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 350;
		t.x = 681.27;
		t.y = 273.97;
		return t;
	};
	_proto.effect_betpos3_i = function () {
		var t = new Effect_betpos_3();
		this.effect_betpos3 = t;
		t.height = 250;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 350;
		t.x = 974.89;
		t.y = 281.3;
		return t;
	};
	_proto.g_dice_i = function () {
		var t = new eui.Group();
		this.g_dice = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.g_click_i = function () {
		var t = new eui.Group();
		this.g_click = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 455.21;
		t.y = 310.57;
		t.elementsContent = [this.rect_shun_i(),this.rect_tian_i(),this.rect_di_i()];
		return t;
	};
	_proto.rect_shun_i = function () {
		var t = new eui.Rect();
		this.rect_shun = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 10;
		t.ellipseWidth = 10;
		t.fillAlpha = 0;
		t.height = 192.25;
		t.scaleX = 1.59;
		t.skewX = 15;
		t.skewY = 0;
		t.width = 166.97;
		t.x = 0;
		t.y = 2;
		return t;
	};
	_proto.rect_tian_i = function () {
		var t = new eui.Rect();
		this.rect_tian = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 10;
		t.ellipseWidth = 10;
		t.fillAlpha = 0;
		t.height = 192.25;
		t.scaleX = 1.59;
		t.skewX = 0;
		t.skewY = 0;
		t.width = 169.49;
		t.x = 265.24;
		t.y = 1.33;
		return t;
	};
	_proto.rect_di_i = function () {
		var t = new eui.Rect();
		this.rect_di = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 10;
		t.ellipseWidth = 10;
		t.fillAlpha = 0;
		t.height = 192.25;
		t.scaleX = 1.59;
		t.skewX = -15;
		t.skewY = 0;
		t.width = 169.49;
		t.x = 535.24;
		t.y = 2;
		return t;
	};
	_proto._ui_i = function () {
		var t = new eui.Group();
		this._ui = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 548;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = true;
		t.elementsContent = [this.right_i(),this.history_i()];
		return t;
	};
	_proto.right_i = function () {
		var t = new eui.Group();
		this.right = t;
		t.bottom = 0;
		t.right = 0;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = false;
		t.elementsContent = [this._Image10_i(),this._Group21_i(),this._chip_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.source = "UI_TTZ_player_01_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group21_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 115.67;
		t.width = 316;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.label_my_nickname_i(),this._Image11_i(),this.label_my_gold_i(),this._Image12_i(),this.label_my_bet_titile_i(),this.label_bet_gold_i(),this.head_panel_i()];
		return t;
	};
	_proto.label_my_nickname_i = function () {
		var t = new eui.Label();
		this.label_my_nickname = t;
		t.anchorOffsetX = 0;
		t.size = 20;
		t.text = "谁是大赢家";
		t.width = 185;
		t.x = 129;
		t.y = 14.31;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.height = 24;
		t.source = "icon_gold_png";
		t.width = 24;
		t.x = 131.03;
		t.y = 42.32;
		return t;
	};
	_proto.label_my_gold_i = function () {
		var t = new eui.Label();
		this.label_my_gold = t;
		t.anchorOffsetX = 0;
		t.size = 18;
		t.text = "99999万";
		t.width = 115;
		t.x = 158.63;
		t.y = 45;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.source = "UI_TTZ_playertotal_01_png";
		t.x = 126.01;
		t.y = 70.72;
		return t;
	};
	_proto.label_my_bet_titile_i = function () {
		var t = new eui.Label();
		this.label_my_bet_titile = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 16.67;
		t.size = 16;
		t.text = "总下注：";
		t.width = 64.34;
		t.x = 135.28;
		t.y = 81.01;
		return t;
	};
	_proto.label_bet_gold_i = function () {
		var t = new eui.Label();
		this.label_bet_gold = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 16.67;
		t.size = 18;
		t.text = "123,123";
		t.textColor = 0xffd403;
		t.width = 111.01;
		t.x = 192.92;
		t.y = 81.01;
		return t;
	};
	_proto.head_panel_i = function () {
		var t = new eui.Group();
		this.head_panel = t;
		t.height = 100;
		t.horizontalCenter = -97;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 2.164999999999999;
		t.width = 100;
		t.elementsContent = [this.img_my_head_i(),this.my_addMoney_i()];
		return t;
	};
	_proto.img_my_head_i = function () {
		var t = new eui.Image();
		this.img_my_head = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "head_1_png";
		t.top = 0;
		return t;
	};
	_proto.my_addMoney_i = function () {
		var t = new AddMoney();
		this.my_addMoney = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.y = 50;
		return t;
	};
	_proto._chip_i = function () {
		var t = new eui.Group();
		this._chip = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 110.67;
		t.width = 577.33;
		t.x = 319.99;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Group22_i(),this._Group23_i(),this._Group24_i(),this._Group25_i(),this._Group26_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 18;
		t.horizontalAlign = "center";
		t.paddingTop = 5;
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Group22_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 90;
		t.width = 90;
		t.x = 56;
		t.y = -48.33;
		t.layout = this._BasicLayout1_i();
		t.elementsContent = [this.chip_1_i()];
		return t;
	};
	_proto._BasicLayout1_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.chip_1_i = function () {
		var t = new eui.Group();
		this.chip_1 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.height = 70;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.touchEnabled = true;
		t.verticalCenter = 0;
		t.width = 70;
		t.elementsContent = [this.img_chip_1_i(),this.img_light_1_i(),this.label_chip1_i()];
		return t;
	};
	_proto.img_chip_1_i = function () {
		var t = new eui.Image();
		this.img_chip_1 = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_chips_101_png";
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.img_light_1_i = function () {
		var t = new eui.Image();
		this.img_light_1 = t;
		t.bottom = -12;
		t.left = -12;
		t.right = -12;
		t.source = "UI_TTZ_chips_light_01_png";
		t.top = -12;
		t.touchEnabled = false;
		return t;
	};
	_proto.label_chip1_i = function () {
		var t = new eui.Label();
		this.label_chip1 = t;
		t.horizontalCenter = 0;
		t.size = 20;
		t.text = "5";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group23_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 90;
		t.width = 90;
		t.x = 66;
		t.y = -38.33;
		t.layout = this._BasicLayout2_i();
		t.elementsContent = [this.chip_2_i()];
		return t;
	};
	_proto._BasicLayout2_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.chip_2_i = function () {
		var t = new eui.Group();
		this.chip_2 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.height = 70;
		t.horizontalCenter = 0;
		t.touchEnabled = true;
		t.verticalCenter = 0;
		t.width = 70;
		t.elementsContent = [this.img_chip_2_i(),this.img_light_2_i(),this.label_chip2_i()];
		return t;
	};
	_proto.img_chip_2_i = function () {
		var t = new eui.Image();
		this.img_chip_2 = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_chips_102_png";
		t.top = 0;
		return t;
	};
	_proto.img_light_2_i = function () {
		var t = new eui.Image();
		this.img_light_2 = t;
		t.bottom = -12;
		t.left = -12;
		t.right = -12;
		t.source = "UI_TTZ_chips_light_01_png";
		t.top = -12;
		return t;
	};
	_proto.label_chip2_i = function () {
		var t = new eui.Label();
		this.label_chip2 = t;
		t.horizontalCenter = 0;
		t.size = 20;
		t.text = "10";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group24_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 90;
		t.width = 90;
		t.x = 76;
		t.y = -28.33;
		t.layout = this._BasicLayout3_i();
		t.elementsContent = [this.chip_3_i()];
		return t;
	};
	_proto._BasicLayout3_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.chip_3_i = function () {
		var t = new eui.Group();
		this.chip_3 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.height = 70;
		t.horizontalCenter = 0;
		t.touchEnabled = true;
		t.verticalCenter = 0;
		t.width = 70;
		t.elementsContent = [this.img_chip_3_i(),this.img_light_3_i(),this.label_chip3_i()];
		return t;
	};
	_proto.img_chip_3_i = function () {
		var t = new eui.Image();
		this.img_chip_3 = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_chips_103_png";
		t.top = 0;
		return t;
	};
	_proto.img_light_3_i = function () {
		var t = new eui.Image();
		this.img_light_3 = t;
		t.bottom = -12;
		t.left = -12;
		t.right = -12;
		t.source = "UI_TTZ_chips_light_01_png";
		t.top = -12;
		return t;
	};
	_proto.label_chip3_i = function () {
		var t = new eui.Label();
		this.label_chip3 = t;
		t.horizontalCenter = 0;
		t.size = 20;
		t.text = "2.5千";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group25_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 90;
		t.width = 90;
		t.x = 86;
		t.y = -18.33;
		t.layout = this._BasicLayout4_i();
		t.elementsContent = [this.chip_4_i()];
		return t;
	};
	_proto._BasicLayout4_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.chip_4_i = function () {
		var t = new eui.Group();
		this.chip_4 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.height = 70;
		t.horizontalCenter = 0;
		t.touchEnabled = true;
		t.verticalCenter = 0;
		t.width = 70;
		t.elementsContent = [this.img_chip_4_i(),this.img_light_4_i(),this.label_chip4_i()];
		return t;
	};
	_proto.img_chip_4_i = function () {
		var t = new eui.Image();
		this.img_chip_4 = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_chips_104_png";
		t.top = 0;
		return t;
	};
	_proto.img_light_4_i = function () {
		var t = new eui.Image();
		this.img_light_4 = t;
		t.bottom = -12;
		t.left = -12;
		t.right = -12;
		t.source = "UI_TTZ_chips_light_01_png";
		t.top = -12;
		return t;
	};
	_proto.label_chip4_i = function () {
		var t = new eui.Label();
		this.label_chip4 = t;
		t.horizontalCenter = 0;
		t.size = 20;
		t.text = "5000";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group26_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 90;
		t.width = 90;
		t.x = 96;
		t.y = -8.329999999999998;
		t.layout = this._BasicLayout5_i();
		t.elementsContent = [this.chip_5_i()];
		return t;
	};
	_proto._BasicLayout5_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.chip_5_i = function () {
		var t = new eui.Group();
		this.chip_5 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.height = 70;
		t.horizontalCenter = 0;
		t.touchEnabled = true;
		t.verticalCenter = 0;
		t.width = 70;
		t.elementsContent = [this.img_chip_5_i(),this.img_light_5_i(),this.label_chip5_i()];
		return t;
	};
	_proto.img_chip_5_i = function () {
		var t = new eui.Image();
		this.img_chip_5 = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_chips_105_png";
		t.top = 0;
		return t;
	};
	_proto.img_light_5_i = function () {
		var t = new eui.Image();
		this.img_light_5 = t;
		t.bottom = -12;
		t.left = -12;
		t.right = -12;
		t.source = "UI_TTZ_chips_light_01_png";
		t.top = -12;
		return t;
	};
	_proto.label_chip5_i = function () {
		var t = new eui.Label();
		this.label_chip5 = t;
		t.horizontalCenter = 0;
		t.size = 20;
		t.text = "999";
		t.verticalCenter = 0;
		return t;
	};
	_proto.history_i = function () {
		var t = new ErbaHistory();
		this.history = t;
		t.bottom = 0;
		t.left = 2;
		t.skinName = "ErbaHistorySkin";
		return t;
	};
	_proto.g_fly_layer_i = function () {
		var t = new eui.Group();
		this.g_fly_layer = t;
		t.bottom = 0;
		t.height = 720;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.touchChildren = false;
		t.touchEnabled = false;
		t.touchThrough = true;
		t.width = 1280;
		return t;
	};
	_proto.top_i = function () {
		var t = new eui.Group();
		this.top = t;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = true;
		t.elementsContent = [this.menu_i(),this._Group27_i(),this.group_playerlist_i(),this.dice_view_i()];
		return t;
	};
	_proto.menu_i = function () {
		var t = new eui.Group();
		this.menu = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 80;
		t.left = 3;
		t.top = 3;
		t.width = 80;
		t.elementsContent = [this._Image13_i(),this.btn_menu_i()];
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_manu_bk_01_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.btn_menu_i = function () {
		var t = new eui.Button();
		this.btn_menu = t;
		t.horizontalCenter = 0;
		t.label = "";
		t.verticalCenter = 0;
		t.skinName = ErbaGameSceneSkin$Skin1;
		return t;
	};
	_proto._Group27_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 32.36;
		t.left = 91;
		t.top = 5;
		t.width = 413.8;
		t.elementsContent = [this._Image14_i(),this.label_game_num_i()];
		return t;
	};
	_proto._Image14_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_manu_bk_01_png";
		t.top = 0;
		return t;
	};
	_proto.label_game_num_i = function () {
		var t = new eui.Label();
		this.label_game_num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fontFamily = "Microsoft YaHei";
		t.left = 0;
		t.right = 0;
		t.size = 18;
		t.text = "牌局编号：100201_0_L0102_5c4b0292c339f_3";
		t.textAlign = "center";
		t.textColor = 0xe2d7d7;
		t.top = 0;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.group_playerlist_i = function () {
		var t = new eui.Group();
		this.group_playerlist = t;
		t.anchorOffsetX = 0;
		t.height = 556;
		t.right = -200;
		t.top = 41;
		t.elementsContent = [this.img_playerlist_i(),this._Group29_i()];
		return t;
	};
	_proto.img_playerlist_i = function () {
		var t = new eui.Image();
		this.img_playerlist = t;
		t.right = 195;
		t.source = "UI_TTZ_allplayers_01_png";
		t.top = 0;
		return t;
	};
	_proto._Group29_i = function () {
		var t = new eui.Group();
		t.height = 556;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.touchChildren = true;
		t.touchThrough = true;
		t.elementsContent = [this._Image15_i(),this._Label5_i(),this._Scroller1_i()];
		return t;
	};
	_proto._Image15_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_allplayers_03_png";
		t.top = 0;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.left = -3;
		t.right = 3;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 16;
		t.text = " 输赢最多的前20名玩家";
		t.textAlign = "center";
		t.textColor = 0xffd403;
		t.top = 11;
		t.verticalAlign = "middle";
		t.x = 0;
		t.y = 12.000000000000007;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.height = 509;
		t.right = 5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.scrollPolicyH = "off";
		t.top = 37;
		t.width = 193;
		t.y = 37;
		t.viewport = this._Group28_i();
		return t;
	};
	_proto._Group28_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.playerlist_i()];
		return t;
	};
	_proto.playerlist_i = function () {
		var t = new eui.List();
		this.playerlist = t;
		t.anchorOffsetY = 0;
		t.itemRenderer = PlayerListItem;
		t.itemRendererSkinName = PlayerListItemSkin;
		t.left = 0;
		t.top = 0;
		t.layout = this._TileLayout1_i();
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._TileLayout1_i = function () {
		var t = new eui.TileLayout();
		t.columnAlign = "left";
		t.horizontalAlign = "center";
		t.horizontalGap = 1;
		t.orientation = "columns";
		t.paddingLeft = 5;
		t.paddingTop = 2;
		t.requestedColumnCount = 1;
		t.rowAlign = "top";
		t.verticalAlign = "middle";
		t.verticalGap = 5;
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i(),this._Object2_i(),this._Object3_i(),this._Object4_i(),this._Object5_i(),this._Object6_i(),this._Object7_i(),this._Object8_i(),this._Object9_i(),this._Object10_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		t.null = "null";
		return t;
	};
	_proto.dice_view_i = function () {
		var t = new DiceView();
		this.dice_view = t;
		t.left = 170;
		t.skinName = "DiceViewSkin";
		t.top = -308;
		return t;
	};
	return ErbaGameSceneSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/hallScene/ErbaHallScene.exml'] = window.ErbaHallSceneSkin = (function (_super) {
	__extends(ErbaHallSceneSkin, _super);
	var ErbaHallSceneSkin$Skin2 = 	(function (_super) {
		__extends(ErbaHallSceneSkin$Skin2, _super);
		function ErbaHallSceneSkin$Skin2() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ErbaHallSceneSkin$Skin2.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "UI_manu_button_07_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ErbaHallSceneSkin$Skin2;
	})(eui.Skin);

	var ErbaHallSceneSkin$Skin3 = 	(function (_super) {
		__extends(ErbaHallSceneSkin$Skin3, _super);
		function ErbaHallSceneSkin$Skin3() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ErbaHallSceneSkin$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "UI_manu_button_02_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ErbaHallSceneSkin$Skin3;
	})(eui.Skin);

	var ErbaHallSceneSkin$Skin4 = 	(function (_super) {
		__extends(ErbaHallSceneSkin$Skin4, _super);
		function ErbaHallSceneSkin$Skin4() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ErbaHallSceneSkin$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "UI_manu_button_02_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ErbaHallSceneSkin$Skin4;
	})(eui.Skin);

	var ErbaHallSceneSkin$Skin5 = 	(function (_super) {
		__extends(ErbaHallSceneSkin$Skin5, _super);
		function ErbaHallSceneSkin$Skin5() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ErbaHallSceneSkin$Skin5.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "UI_manu_button_04_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ErbaHallSceneSkin$Skin5;
	})(eui.Skin);

	function ErbaHallSceneSkin() {
		_super.call(this);
		this.skinParts = ["bg","btnHelp","btnRecord","btnSetting","btnBack","menuGroup","imgHeader","lbUserName","scoreIcon","lbUserCoins","headInfoGroup","top","imgToplimit","lbTopLimit","topLimit","gameList1","gameTabList1","gameList2","gameTabList2","gameList3","gameTabList3","gameList4","gameTabList4","gameList","gameTabBar","ui_marqueeText","G_paomadeng","bottom"];
		
		this.height = 720;
		this.width = 1280;
		this.elementsContent = [this.bg_i(),this.top_i(),this.gameList_i(),this.bottom_i()];
	}
	var _proto = ErbaHallSceneSkin.prototype;

	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_roombg_01_jpg";
		t.top = 0;
		return t;
	};
	_proto.top_i = function () {
		var t = new eui.Group();
		this.top = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 128;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.menuGroup_i(),this.headInfoGroup_i(),this._Image3_i()];
		return t;
	};
	_proto.menuGroup_i = function () {
		var t = new eui.Group();
		this.menuGroup = t;
		t.anchorOffsetY = 0;
		t.height = 88.67;
		t.right = 5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 3;
		t.width = 262;
		t.y = 10;
		t.elementsContent = [this._Image1_i(),this.btnHelp_i(),this.btnRecord_i(),this.btnSetting_i(),this.btnBack_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_manu_bk_01_png";
		t.top = 0;
		return t;
	};
	_proto.btnHelp_i = function () {
		var t = new eui.Button();
		this.btnHelp = t;
		t.horizontalCenter = -1;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 1.6649999999999991;
		t.skinName = ErbaHallSceneSkin$Skin2;
		return t;
	};
	_proto.btnRecord_i = function () {
		var t = new eui.Button();
		this.btnRecord = t;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.x = 14;
		t.y = 14;
		t.skinName = ErbaHallSceneSkin$Skin3;
		return t;
	};
	_proto.btnSetting_i = function () {
		var t = new eui.Button();
		this.btnSetting = t;
		t.horizontalCenter = -85;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 1.6649999999999991;
		t.skinName = ErbaHallSceneSkin$Skin4;
		return t;
	};
	_proto.btnBack_i = function () {
		var t = new eui.Button();
		this.btnBack = t;
		t.horizontalCenter = 87;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 1.6649999999999991;
		t.skinName = ErbaHallSceneSkin$Skin5;
		return t;
	};
	_proto.headInfoGroup_i = function () {
		var t = new eui.Group();
		this.headInfoGroup = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 88;
		t.left = 5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 3;
		t.width = 289;
		t.y = 0;
		t.elementsContent = [this._Image2_i(),this.imgHeader_i(),this.lbUserName_i(),this.scoreIcon_i(),this.lbUserCoins_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_manu_bk_01_png";
		t.top = 0;
		return t;
	};
	_proto.imgHeader_i = function () {
		var t = new eui.Image();
		this.imgHeader = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 88;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "head_10_png";
		t.width = 88;
		t.y = 1;
		return t;
	};
	_proto.lbUserName_i = function () {
		var t = new eui.Label();
		this.lbUserName = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 24;
		t.left = 102;
		t.right = 13;
		t.size = 24;
		t.text = "名字有六个字";
		t.textColor = 0xffffff;
		t.top = 17;
		return t;
	};
	_proto.scoreIcon_i = function () {
		var t = new eui.Image();
		this.scoreIcon = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_gold_png";
		t.x = 98;
		t.y = 54;
		return t;
	};
	_proto.lbUserCoins_i = function () {
		var t = new eui.Label();
		this.lbUserCoins = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 25;
		t.left = 130;
		t.right = 12;
		t.size = 24;
		t.text = "999999";
		t.textColor = 0xfece8f;
		t.y = 53;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_logo_01_png";
		t.top = -2;
		return t;
	};
	_proto.gameList_i = function () {
		var t = new eui.Group();
		this.gameList = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 130;
		t.left = 0;
		t.right = 0;
		t.top = 130;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = true;
		t.elementsContent = [this.topLimit_i(),this.gameTabList1_i(),this.gameTabList2_i(),this.gameTabList3_i(),this.gameTabList4_i()];
		return t;
	};
	_proto.topLimit_i = function () {
		var t = new eui.Group();
		this.topLimit = t;
		t.anchorOffsetY = 0;
		t.height = 65;
		t.horizontalCenter = 0;
		t.verticalCenter = 180;
		t.elementsContent = [this.imgToplimit_i(),this.lbTopLimit_i()];
		return t;
	};
	_proto.imgToplimit_i = function () {
		var t = new eui.Image();
		this.imgToplimit = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_xianhong_01_png";
		t.top = 0;
		return t;
	};
	_proto.lbTopLimit_i = function () {
		var t = new eui.Label();
		this.lbTopLimit = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "限红：100-10000";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.verticalCenter = -5;
		return t;
	};
	_proto.gameTabList1_i = function () {
		var t = new eui.Scroller();
		this.gameTabList1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.gameList1_i()];
		return t;
	};
	_proto.gameList1_i = function () {
		var t = new eui.List();
		this.gameList1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.itemRenderer = HallListItem;
		t.itemRendererSkinName = HallListItemSkin;
		t.left = 0;
		t.scrollEnabled = true;
		t.touchEnabled = true;
		t.verticalCenter = -24;
		t.layout = this._HorizontalLayout1_i();
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = -10;
		t.horizontalAlign = "center";
		t.paddingLeft = -8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto.gameTabList2_i = function () {
		var t = new eui.Scroller();
		this.gameTabList2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this._Group2_i();
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.gameList2_i()];
		return t;
	};
	_proto.gameList2_i = function () {
		var t = new eui.List();
		this.gameList2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.itemRenderer = HallListItem;
		t.itemRendererSkinName = HallListItemSkin;
		t.left = 0;
		t.scrollEnabled = true;
		t.touchEnabled = true;
		t.verticalCenter = -24;
		t.layout = this._HorizontalLayout2_i();
		return t;
	};
	_proto._HorizontalLayout2_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = -10;
		t.horizontalAlign = "center";
		t.paddingLeft = -8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.gameTabList3_i = function () {
		var t = new eui.Scroller();
		this.gameTabList3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this._Group3_i();
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.gameList3_i()];
		return t;
	};
	_proto.gameList3_i = function () {
		var t = new eui.List();
		this.gameList3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.itemRenderer = HallListItem;
		t.itemRendererSkinName = HallListItemSkin;
		t.left = 0;
		t.scrollEnabled = true;
		t.touchEnabled = true;
		t.verticalCenter = -24;
		t.layout = this._HorizontalLayout3_i();
		return t;
	};
	_proto._HorizontalLayout3_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = -10;
		t.horizontalAlign = "center";
		t.paddingLeft = -8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.gameTabList4_i = function () {
		var t = new eui.Scroller();
		this.gameTabList4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this._Group4_i();
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.gameList4_i()];
		return t;
	};
	_proto.gameList4_i = function () {
		var t = new eui.List();
		this.gameList4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.itemRenderer = HallListItem;
		t.itemRendererSkinName = HallListItemSkin;
		t.left = 0;
		t.scrollEnabled = true;
		t.touchEnabled = true;
		t.verticalCenter = -24;
		t.layout = this._HorizontalLayout4_i();
		return t;
	};
	_proto._HorizontalLayout4_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = -10;
		t.horizontalAlign = "center";
		t.paddingLeft = -8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.bottom_i = function () {
		var t = new eui.Group();
		this.bottom = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.height = 150;
		t.left = 0;
		t.right = 0;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = true;
		t.elementsContent = [this._Image4_i(),this.gameTabBar_i(),this.G_paomadeng_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_TTZ_roomBG_02_png";
		t.top = 0;
		return t;
	};
	_proto.gameTabBar_i = function () {
		var t = new eui.TabBar();
		this.gameTabBar = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 59;
		t.height = 70;
		t.horizontalCenter = -9;
		t.itemRendererSkinName = ErbaTabBarItemSkin;
		t.width = 887;
		t.dataProvider = this._ArrayCollection2_i();
		return t;
	};
	_proto._ArrayCollection2_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object2_i(),this._Object3_i(),this._Object4_i(),this._Object5_i()];
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.img_normal = "UI_TTZ_room_button_01_png";
		t.img_selected = "UI_TTZ_room_button_01_2_png";
		t.img_text = "UI_TTZ_roomtatle_01_png";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.img_normal = "UI_TTZ_room_button_02_png";
		t.img_selected = "UI_TTZ_room_button_02_2_png";
		t.img_text = "UI_TTZ_roomtatle_02_png";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.img_normal = "UI_TTZ_room_button_03_png";
		t.img_selected = "UI_TTZ_room_button_03_2_png";
		t.img_text = "UI_TTZ_roomtatle_03_png";
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		t.img_normal = "UI_TTZ_room_button_04_png";
		t.img_selected = "UI_TTZ_room_button_04_2_png";
		t.img_text = "UI_TTZ_roomtatle_04_png";
		return t;
	};
	_proto.G_paomadeng_i = function () {
		var t = new eui.Group();
		this.G_paomadeng = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.height = 46;
		t.left = 0;
		t.right = 0;
		t.elementsContent = [this._Image5_i(),this.ui_marqueeText_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.alpha = 0.6;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "UI_manu_bk_01_png";
		t.top = 0;
		return t;
	};
	_proto.ui_marqueeText_i = function () {
		var t = new Common.MarqueeText();
		this.ui_marqueeText = t;
		t.skinName = "MarqueeTextSkin";
		t.verticalCenter = 0;
		t.x = 0;
		return t;
	};
	return ErbaHallSceneSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/hallScene/ErbaHistoryItem.exml'] = window.ErbaHistoryItemSkin = (function (_super) {
	__extends(ErbaHistoryItemSkin, _super);
	function ErbaHistoryItemSkin() {
		_super.call(this);
		this.skinParts = ["result0","result1","cardFrame","cardFrameNew"];
		
		this.height = 41;
		this.minHeight = 50;
		this.minWidth = 100;
		this.width = 61;
		this.elementsContent = [this._Group1_i(),this.cardFrame_i(),this.cardFrameNew_i()];
	}
	var _proto = ErbaHistoryItemSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this.result0_i(),this.result1_i()];
		return t;
	};
	_proto.result0_i = function () {
		var t = new eui.Image();
		this.result0 = t;
		t.horizontalCenter = -12;
		t.source = "UI_TTZ_majiang_04_png";
		t.verticalCenter = 2;
		return t;
	};
	_proto.result1_i = function () {
		var t = new eui.Image();
		this.result1 = t;
		t.horizontalCenter = 15;
		t.source = "UI_TTZ_majiang_14_png";
		t.verticalCenter = 2;
		return t;
	};
	_proto.cardFrame_i = function () {
		var t = new eui.Image();
		this.cardFrame = t;
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_frame_green_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.cardFrameNew_i = function () {
		var t = new eui.Image();
		this.cardFrameNew = t;
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_frame_yellow_png";
		t.verticalCenter = 0;
		return t;
	};
	return ErbaHistoryItemSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/hallScene/ErbaTabBarItem.exml'] = window.ErbaTabBarItemSkin = (function (_super) {
	__extends(ErbaTabBarItemSkin, _super);
	function ErbaTabBarItemSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image2_i()];
		this._Image1_i();
		
		this._Image3_i();
		
		this.states = [
			new eui.State ("up",
				[
					new eui.AddItems("_Image1","",0,""),
					new eui.AddItems("_Image3","",1,""),
					new eui.SetStateProperty(this, ["hostComponent.data.img_normal"],[0],this._Image1,"source"),
					new eui.SetStateProperty(this, ["hostComponent.data.img_selected"],[0],this._Image2,"source"),
					new eui.SetProperty("_Image2","visible",false),
					new eui.SetProperty("_Image3","verticalCenter",-3.5),
					new eui.SetStateProperty(this, ["hostComponent.data.img_text"],[0],this._Image3,"source")
				])
			,
			new eui.State ("down",
				[
					new eui.AddItems("_Image1","",0,""),
					new eui.AddItems("_Image3","",1,""),
					new eui.SetStateProperty(this, ["hostComponent.data.img_normal"],[0],this._Image1,"source"),
					new eui.SetProperty("_Image1","visible",false),
					new eui.SetStateProperty(this, ["hostComponent.data.img_selected"],[0],this._Image2,"source"),
					new eui.SetProperty("_Image3","horizontalCenter",0.5),
					new eui.SetStateProperty(this, ["hostComponent.data.img_text"],[0],this._Image3,"source")
				])
		];
	}
	var _proto = ErbaTabBarItemSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_room_button_01_png";
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = 0;
		t.source = "UI_TTZ_room_button_01_2_png";
		t.top = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		this._Image3 = t;
		t.horizontalCenter = 0.5;
		t.source = "UI_TTZ_roomtatle_01_png";
		t.touchEnabled = true;
		t.verticalCenter = -3.5;
		return t;
	};
	return ErbaTabBarItemSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/hallScene/HallListItem.exml'] = window.HallListItemSkin = (function (_super) {
	__extends(HallListItemSkin, _super);
	function HallListItemSkin() {
		_super.call(this);
		this.skinParts = ["bg","gameListItem","roomId","gameLineNum","gameState","goldLimit","gameListTitle","cardList","resultNum4","resultNum1","resultNum2","resultNum3","resultNumGroup","touchGroup"];
		
		this.height = 346;
		this.minHeight = 346;
		this.minWidth = 100;
		this.width = 564;
		this.elementsContent = [this.touchGroup_i()];
	}
	var _proto = HallListItemSkin.prototype;

	_proto.touchGroup_i = function () {
		var t = new eui.Group();
		this.touchGroup = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this.bg_i(),this.gameListItem_i(),this.gameListTitle_i(),this._Scroller1_i(),this.resultNumGroup_i()];
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_TTZ_room_01_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.gameListItem_i = function () {
		var t = new eui.Group();
		this.gameListItem = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 95;
		t.left = 90;
		t.right = 92;
		t.top = 105;
		t.touchEnabled = false;
		return t;
	};
	_proto.gameListTitle_i = function () {
		var t = new eui.Group();
		this.gameListTitle = t;
		t.height = 34;
		t.left = 88;
		t.right = 90;
		t.top = 72;
		t.elementsContent = [this.roomId_i(),this.gameLineNum_i(),this.gameState_i(),this.goldLimit_i()];
		return t;
	};
	_proto.roomId_i = function () {
		var t = new eui.Label();
		this.roomId = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 20;
		t.horizontalCenter = -134;
		t.size = 16;
		t.text = "L10010";
		t.textAlign = "center";
		t.textColor = 0xd3e8e3;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 112;
		return t;
	};
	_proto.gameLineNum_i = function () {
		var t = new eui.Label();
		this.gameLineNum = t;
		t.fontFamily = "Microsoft YaHei";
		t.height = 20;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 16;
		t.text = "512在线人数";
		t.textAlign = "center";
		t.textColor = 0xd3e8e3;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 133;
		return t;
	};
	_proto.gameState_i = function () {
		var t = new eui.Label();
		this.gameState = t;
		t.fontFamily = "Microsoft YaHei";
		t.height = 20;
		t.horizontalCenter = 134;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 16;
		t.text = "下注中11111";
		t.textAlign = "center";
		t.textColor = 0xd3e8e3;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 112;
		return t;
	};
	_proto.goldLimit_i = function () {
		var t = new eui.Label();
		this.goldLimit = t;
		t.fontFamily = "Microsoft YaHei";
		t.size = 15;
		t.text = "投注限额 1-500";
		t.textColor = 0xD7C289;
		t.verticalCenter = 0;
		t.visible = false;
		t.x = 270;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 145;
		t.left = 177;
		t.rotation = 0;
		t.scrollPolicyH = "off";
		t.scrollPolicyV = "off";
		t.top = 108;
		t.width = 295;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetY = 0;
		t.x = 0;
		t.y = 50.57;
		t.elementsContent = [this.cardList_i()];
		return t;
	};
	_proto.cardList_i = function () {
		var t = new eui.List();
		this.cardList = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 145;
		t.itemRenderer = ErbaHistoryItem;
		t.itemRendererSkinName = ErbaHistoryItemSkin;
		t.scaleX = 1;
		t.scaleY = 1;
		t.useVirtualLayout = false;
		t.width = 295;
		t.layout = this._TileLayout1_i();
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._TileLayout1_i = function () {
		var t = new eui.TileLayout();
		t.columnAlign = "left";
		t.columnWidth = 68;
		t.horizontalAlign = "center";
		t.horizontalGap = 4;
		t.orientation = "columns";
		t.paddingLeft = 8;
		t.paddingTop = 1;
		t.requestedColumnCount = 4;
		t.requestedRowCount = 4;
		t.rowAlign = "top";
		t.rowHeight = 32;
		t.verticalAlign = "middle";
		t.verticalGap = 4;
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i(),this._Object2_i(),this._Object3_i(),this._Object4_i(),this._Object5_i(),this._Object6_i(),this._Object7_i(),this._Object8_i(),this._Object9_i(),this._Object10_i(),this._Object11_i(),this._Object12_i(),this._Object13_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		t.null = "";
		return t;
	};
	_proto.resultNumGroup_i = function () {
		var t = new eui.Group();
		this.resultNumGroup = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 150;
		t.left = 134;
		t.verticalCenter = 7.5;
		t.width = 43;
		t.elementsContent = [this.resultNum4_i(),this.resultNum1_i(),this.resultNum2_i(),this.resultNum3_i()];
		return t;
	};
	_proto.resultNum4_i = function () {
		var t = new eui.Label();
		this.resultNum4 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 1;
		t.size = 22;
		t.text = "0";
		t.textColor = 0x64ffff;
		t.y = 9.36;
		return t;
	};
	_proto.resultNum1_i = function () {
		var t = new eui.Label();
		this.resultNum1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 1;
		t.size = 22;
		t.text = "0";
		t.textColor = 0x64ffff;
		t.y = 47.17;
		return t;
	};
	_proto.resultNum2_i = function () {
		var t = new eui.Label();
		this.resultNum2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 1;
		t.size = 22;
		t.text = "0";
		t.textColor = 0x64ffff;
		t.y = 80.98;
		return t;
	};
	_proto.resultNum3_i = function () {
		var t = new eui.Label();
		this.resultNum3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 1;
		t.size = 22;
		t.text = "0";
		t.textColor = 0x64ffff;
		t.y = 118.16;
		return t;
	};
	return HallListItemSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/help/HelpSkin.exml'] = window.HelpSkin = (function (_super) {
	__extends(HelpSkin, _super);
	var HelpSkin$Skin6 = 	(function (_super) {
		__extends(HelpSkin$Skin6, _super);
		function HelpSkin$Skin6() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","h_record_close_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = HelpSkin$Skin6.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "h_record_close_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return HelpSkin$Skin6;
	})(eui.Skin);

	function HelpSkin() {
		_super.call(this);
		this.skinParts = ["closeBtn"];
		
		this.height = 598;
		this.width = 646;
		this.elementsContent = [this._Rect1_i(),this._Group2_i()];
	}
	var _proto = HelpSkin.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.5;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 598;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image1_i(),this.closeBtn_i(),this._Image2_i(),this._Scroller1_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "lh_help_bg_png";
		return t;
	};
	_proto.closeBtn_i = function () {
		var t = new eui.Button();
		this.closeBtn = t;
		t.label = "";
		t.right = -2;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = -1;
		t.x = 599;
		t.y = -1;
		t.skinName = HelpSkin$Skin6;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "lh_help_wenzi_png";
		t.top = 8;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.bottom = 28;
		t.horizontalCenter = 0;
		t.top = 66;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this._Image3_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "lh_help_content_png";
		t.top = 0;
		t.x = -35;
		t.y = -58;
		return t;
	};
	return HelpSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/record/RecordItemSkin.exml'] = window.RecordItemSkin = (function (_super) {
	__extends(RecordItemSkin, _super);
	function RecordItemSkin() {
		_super.call(this);
		this.skinParts = ["bg","num","id","roomName","score","endTime"];
		
		this.height = 52;
		this.minHeight = 50;
		this.minWidth = 100;
		this.width = 952;
		this.elementsContent = [this.bg_i(),this.num_i(),this.id_i(),this.roomName_i(),this.score_i(),this.endTime_i()];
	}
	var _proto = RecordItemSkin.prototype;

	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.source = "h_record_bg2_png";
		return t;
	};
	_proto.num_i = function () {
		var t = new eui.Label();
		this.num = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -410;
		t.size = 20;
		t.text = "1";
		t.textAlign = "center";
		t.textColor = 0xa47f43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	_proto.id_i = function () {
		var t = new eui.Label();
		this.id = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -200;
		t.size = 20;
		t.text = "50-1517890401-1234567890-1";
		t.textAlign = "center";
		t.textColor = 0xffef77;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	_proto.roomName_i = function () {
		var t = new eui.Label();
		this.roomName = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -7.5;
		t.size = 20;
		t.text = "初级房";
		t.textAlign = "center";
		t.textColor = 0xa47f43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 105;
		return t;
	};
	_proto.score_i = function () {
		var t = new eui.Label();
		this.score = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 130;
		t.size = 20;
		t.text = "+1234555";
		t.textAlign = "center";
		t.textColor = 0xcd5858;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto.endTime_i = function () {
		var t = new eui.Label();
		this.endTime = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 345;
		t.size = 20;
		t.text = "+1234555";
		t.textAlign = "center";
		t.textColor = 0xa47f43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 260;
		return t;
	};
	return RecordItemSkin;
})(eui.Skin);generateEUI.paths['resource/skins/erba/record/RecordSkin.exml'] = window.RecordSkin = (function (_super) {
	__extends(RecordSkin, _super);
	var RecordSkin$Skin7 = 	(function (_super) {
		__extends(RecordSkin$Skin7, _super);
		function RecordSkin$Skin7() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","h_record_close_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = RecordSkin$Skin7.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "h_record_close_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return RecordSkin$Skin7;
	})(eui.Skin);

	function RecordSkin() {
		_super.call(this);
		this.skinParts = ["bg","title","closeBtn","recordNumber","recordId","recordName","recordScore","recordTime","titleGroup","recordList","recordScorller","recordListGroup","noGameRecordLabel"];
		
		this.height = 506;
		this.width = 992;
		this.elementsContent = [this._Rect1_i(),this._Group2_i()];
	}
	var _proto = RecordSkin.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.5;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 506;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 992;
		t.elementsContent = [this.bg_i(),this.title_i(),this.closeBtn_i(),this.titleGroup_i(),this.recordListGroup_i(),this.noGameRecordLabel_i(),this._Label1_i()];
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "lh_record_bg_png";
		t.verticalCenter = 0;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Image();
		this.title = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "h_record_wenzi_png";
		t.top = 0;
		t.x = 324;
		t.y = 0;
		return t;
	};
	_proto.closeBtn_i = function () {
		var t = new eui.Button();
		this.closeBtn = t;
		t.label = "";
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.x = 935;
		t.y = 0;
		t.skinName = RecordSkin$Skin7;
		return t;
	};
	_proto.titleGroup_i = function () {
		var t = new eui.Group();
		this.titleGroup = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 100;
		t.width = 952;
		t.x = 20;
		t.y = 100;
		t.elementsContent = [this.recordNumber_i(),this.recordId_i(),this.recordName_i(),this.recordScore_i(),this.recordTime_i()];
		return t;
	};
	_proto.recordNumber_i = function () {
		var t = new eui.Label();
		this.recordNumber = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -410;
		t.size = 22;
		t.text = "序号";
		t.textAlign = "center";
		t.textColor = 0xa47f43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 123;
		return t;
	};
	_proto.recordId_i = function () {
		var t = new eui.Label();
		this.recordId = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -200;
		t.size = 22;
		t.text = "牌局编号";
		t.textAlign = "center";
		t.textColor = 0xA47F43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 280;
		return t;
	};
	_proto.recordName_i = function () {
		var t = new eui.Label();
		this.recordName = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = -7.5;
		t.size = 22;
		t.text = "房间";
		t.textAlign = "center";
		t.textColor = 0xA47F43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 105;
		return t;
	};
	_proto.recordScore_i = function () {
		var t = new eui.Label();
		this.recordScore = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 130;
		t.size = 22;
		t.text = "盈利";
		t.textAlign = "center";
		t.textColor = 0xA47F43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto.recordTime_i = function () {
		var t = new eui.Label();
		this.recordTime = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 345;
		t.size = 22;
		t.text = "结束时间";
		t.textAlign = "center";
		t.textColor = 0xA47F43;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 260;
		return t;
	};
	_proto.recordListGroup_i = function () {
		var t = new eui.Group();
		this.recordListGroup = t;
		t.height = 315;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 144;
		t.width = 952;
		t.x = 20;
		t.y = 144;
		t.elementsContent = [this.recordScorller_i()];
		return t;
	};
	_proto.recordScorller_i = function () {
		var t = new eui.Scroller();
		this.recordScorller = t;
		t.height = 315;
		t.horizontalCenter = 0;
		t.width = 952;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.recordList_i()];
		return t;
	};
	_proto.recordList_i = function () {
		var t = new eui.List();
		this.recordList = t;
		t.itemRenderer = RecordItem;
		t.itemRendererSkinName = RecordItemSkin;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 952;
		t.x = 0;
		t.y = 0;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		t.horizontalAlign = "center";
		return t;
	};
	_proto.noGameRecordLabel_i = function () {
		var t = new eui.Label();
		this.noGameRecordLabel = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "";
		t.verticalCenter = 0;
		t.x = 496;
		t.y = 253;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bottom = 13;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 20;
		t.text = "显示最近10条游戏记录";
		t.textColor = 0xffeebf;
		t.x = 396;
		t.y = 473;
		return t;
	};
	return RecordSkin;
})(eui.Skin);generateEUI.paths['resource/skins/LoadingUISkin.exml'] = window.LoadingUISkin = (function (_super) {
	__extends(LoadingUISkin, _super);
	function LoadingUISkin() {
		_super.call(this);
		this.skinParts = ["bg","pb","tip"];
		
		this.height = 720;
		this.width = 1280;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = LoadingUISkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.bg_i(),this._Image1_i(),this._Image2_i(),this.pb_i(),this.tip_i()];
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "loading_bg_jpg";
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "loading_logo_png";
		t.verticalCenter = 132;
		t.x = 468;
		t.y = 447;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "UI_common_loading_03_png";
		t.verticalCenter = 228.5;
		t.x = 512;
		t.y = 577;
		return t;
	};
	_proto.pb_i = function () {
		var t = new eui.ProgressBar();
		this.pb = t;
		t.direction = "ltr";
		t.height = 20;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.skinName = "skins.ProgressBarSkin";
		t.value = 100;
		t.verticalCenter = 261;
		t.x = 450;
		t.y = 612;
		return t;
	};
	_proto.tip_i = function () {
		var t = new eui.Label();
		this.tip = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "Microsoft YaHei";
		t.height = 26;
		t.horizontalCenter = 0.5;
		t.size = 20;
		t.text = "资源加载中...";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = 285;
		t.width = 447;
		return t;
	};
	return LoadingUISkin;
})(eui.Skin);